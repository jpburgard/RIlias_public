# DAT <- read.csv("/home/jpb/Lehre/Lehre/StatistikII/Klausur/ISNK14/Klausur Induktive Statistik WiSe2014_2015.csv",sep=";",header=FALSE,stringsAsFactors=F)
# 
# DATA <- cbind(DAT[seq(2,nrow(DAT),2),],DAT[seq(1,nrow(DAT)-1,2),])
# 
# colnames(DATA)[1:19] <- DATA[1,26+(1:19)]
# DATA<-DATA[,-c(26+(1:19))]
# colnames(DATA)[20:26] <- paste("P",1:7,sep="")
# colnames(DATA)[27:33] <- paste("Q",1:7,sep="")
# rownames(DATA)<-NULL
# write.csv(DATA,"/home/jpb/Lehre/Lehre/StatistikII/Klausur/ISNK14/Klausur Induktive Statistik WiSe2014_2015_Geparsed.csv")
