#######################################################################################################################################################
# LIST OF QUESTION TYPES
#
#  Numeric
#  NumericGaps
#  SingleChoice
#  MultipleChoice
#  Matching
#  Ordering
#  ImageMap
#
#######################################################################################################################################################

# helpfunctions:

Laspeyres <- function(palt,pneu,qalt,qneu,type){
  if(type=="price"){
    sum(pneu*qalt)/(sum(palt*qalt))
  }
  else sum(qneu*palt)/(sum(qalt*palt))
}

Paasche <- function(palt,pneu,qalt,qneu,type){
  if(type=="price"){
    sum(pneu*qneu)/(sum(palt*qneu))
  }
  else sum(qneu*pneu)/(sum(qalt*pneu))
}

Fisher <- function(palt,pneu,qalt,qneu,type){
  if(type=="price"){
    sqrt(Laspeyres(palt,pneu,qalt,qneu,type="price")*Paasche(palt,pneu,qalt,qneu,type="price"))
  }
  else sqrt(Laspeyres(palt,pneu,qalt,qneu,type="quantity")*Paasche(palt,pneu,qalt,qneu,type="quantity"))
}

Value <- function(palt,pneu,qalt,qneu){
  Laspeyres(palt,pneu,qalt,qneu,type="price")*Paasche(palt,pneu,qalt,qneu,type="quantity")
}

#qalt <- c(12,25,30,10,12,18)
#qneu <- c(10,23,42,14,8,23)
#palt <- c(2.7,0.13,0.6,0.8,6.9,1.9)
#pneu <- c(2.9,0.15,0.55,0.75,5.9,2.1)
#Laspeyres(palt,pneu,qalt,qneu,type="price")
#Laspeyres(palt,pneu,qalt,qneu,type="quantity")
#Paasche(palt,pneu,qalt,qneu,type="price")
#Paasche(palt,pneu,qalt,qneu,type="quantity")
#Fisher(palt,pneu,qalt,qneu,type="price")
#Fisher(palt,pneu,qalt,qneu,type="quantity")

#######################################################################################################################################################
#
# 		NUMERIC QUESTIONS
#
#######################################################################################################################################################


### 1) Numerical question: Calculation of the coefficient of determination out of a simple regression model


NumQ_Regression_R.Squared <- function(Text,Question,Points,tol,Titel,iter,y,x){

  reg <- lm(y~x)
  n<-length(y)
  Answer <- round(summary(reg)$r.squared,4)
  Tab <- matrix(NA,ncol=n+1,nrow=3)
  Tab[1,] <- c("i",1:n)
  Tab[2,] <- c("X",x)
  Tab[3,] <- c("Y",y)

  return(
    Question(Type="Numeric", Text=Text, Tab=Tab, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=sprintf("%g",round(c(Answer*(1-tol),Answer*(1+tol)),4)),Points=Points)
  )
}

### Example for function call:

#NumQ_Regression_R2(

#    Text = "Let X and Y be two metric variables. Y is considered to be dependent on X. The following table provides information on the values of the variables:",   # description of task or issue of the question
#    Titel = "Question_Reg_R2_",     # number or content of the question
#    Quest = "Please caculate the coefficient of determination for a simple regression model.",   # formulation of a concrete question
#    Points = 4,     # number of points can be choosed depending on degree of difficulty, for example
#    tol = 0.001,     # range of tolerance to take into account possible rounding errors (can also be set to cero)
#    iter = x,      # number of different questions that should be generated
#    x = sample(1:25,10),     # vector of values for x variable
#    y = sample(20:80,10)     # vector of values for y variable
#)

## Further comments:
## -
# -




### 2) Numerical question: Calculation of arithmetic mean, variance or variation coefficient


NumQ_Mean_Variance_VarCoeff <- function(Text,Question,Points,tol,Titel,iter,x){

  n<-length(x)
  variation.question <- sample(1:3,1)
  Multiple.Questions <- c("arithmetic mean","variance","variation coefficient")
  Question <- paste("Please caculate the",Multiple.Questions[variation.question],"for the given values of X.")
  Answer <- function(x,type){

        mean <- mean(x)
        variance <- var(x) * (n-1)/n
        var.coeff <- sqrt(variance)/mean

        switch(type,
            Q1 = mean,
            Q2 = variance,
            Q3 = var.coeff
        )
  }
  Answer <- Answer(x,c("Q1","Q2","Q3")[variation.question])
  Tab <- matrix(NA,ncol=n+1,nrow=1)
  Tab[1,] <- c("Values for x",x)

  return(
    Question(Type="Numeric", Text=Text, Tab=Tab, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=sprintf("%g",round(c(Answer*(1-tol),Answer*(1+tol)),4)),Points=Points)
  )
}

#### Example for function call:

#NumQ_Mean_Variance_VarCoeff (

#    Text = "The following table provides information on the values of a metric variable X:",   # description of task or issue of the question
#    Titel = "Question_ChangingQuestion_",     # number or content of the question
#    Quest = Question,   # formulation of a concrete question -> if multiple Question are possible, the question needs to be definde within the function of the question (see above)
#    Points = 3,     # number of points can be choosed depending on degree of difficulty, for example
#    tol = 0.001,     # range of tolerance to take into account possible rounding errors (can also be set to cero)
#    iter = x,      # number of different questions that should be generated
#    x = sample(1:25,10)     # vector of values for x variable
#)


# Further comments:
# -
# -




### 3) Numerical question: Calculation of a gini coefficient

NumQ_Gini <- function(Text,Question,Points,tol,Titel,iter,N,classes,class.borders,min.steps){
  n <- getprobs(N,classes,min.steps) # number of elements within the classes (see more information on function "getprobs" below) -> must sum up to N
  x <- cbind(NA,length(classes))
  for(i in 1:classes){
    x[i] <- sum(sample(seq(class.borders[i],class.borders[i+1],10),n[i],replace=TRUE))
  }
  u <- cumsum(n/N)
  v <- cumsum(x/sum(x))
  gini <- sum(u[-length(u)] * v[-1]) - sum(u[-1] * v[-length(v)])
  Answer <- gini

  Tab <- matrix(NA,ncol=3,nrow=classes+1)
  Tab[,1] <- c("Turnover (in Mio. Euro)","0 to 50","50 to 100","100 to 150","150 to 300")
  Tab[,2] <- c("Number of companies",n)
  Tab[,3] <- c("Turnover of classes (in Mio. Euro)",x)
  return(
    Question(Type="Numeric", Text=Text, Tab=Tab, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=sprintf("%g",round(c(Answer*(1-tol),Answer*(1+tol)),4)),Points=Points)
  )
}

### Example for function call:

#NumQ_Gini(
#    Text = "The following table provides information on the values of a metric variable X:",   # description of task or issue of the question
#    Titel = "Question_Gini_",     # number or content of the question
#    Quest = "Please calculate the gini coefficient for the given informations",   # formulation of a concrete question -> if multiple Question are possible, the question needs to be definde within the function of the question (see above)
#    Points = 5,     # number of points can be choosed depending on degree of difficulty, for example
#    tol = 0.001,     # range of tolerance to take into account possible rounding errors (can also be set to cero)
#    iter = x,      # number of different questions that should be generated
#    N <- 200,    # Total number of elements for a certain characteristic
#    classes <- 4, # Total number of different classes of the characteristic
#    class.borders <- c(0,50,100,150,300),  # borders for classes, for which elements can be drawn randomly -> n elements for each class,
#    min.steps = 5 # Minimal step length
#)

# Further comments:
# -
# -


### 4) Numerical Question: Calculation of absolute and relative frequencies

NumQ_Freq <- function(Text,Question=NULL,Points,Titel,tol,iter,codes,Ncodes,N,varQ="random"){
  elements <- codes[1:Ncodes]
  X <- sample(elements,N,replace=T)

  if(varQ!="random") {variation.question <- varQ}
  variation.question <- sample(1:2,1)
  Multiple.Questions <- c("absolute frequency","relative frequency")
  Item <- sample(1:Ncodes,1)

  freq <- table(X)

  Question <- paste("The total sample size is", N,". Please calculate the",Multiple.Questions[variation.question],"for X =", names(freq[Item]),".")

  Answer <- function(x,type,Item){

        abs_freq <- table(x)[[Item]]
        rel_freq <- table(x)[[Item]]/N

        switch(type,
            Q1 = abs_freq,
            Q2 = rel_freq
        )
  }
  Answer <- Answer(X,c("Q1","Q2")[variation.question],Item)
  Tab <- matrix(NA,ncol=N+1,nrow=1)
  Tab[1,] <- c("Values for x",X)

  if(varQ==1) {
      Tab <- matrix(freq/N,nrow=1)
    rownames(Tab) <- "Values for X"
      colnames(Tab) <- names(freq)
  }

  return(
    Question(Type="Numeric", Text=Text, Tab=Tab, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=sprintf("%g",round(c(Answer*(1-tol),Answer*(1+tol)),4)),Points=Points)
  )

}

#### Example for function call:

## NumQ_Freq (
##     Text = "The following table provides information on the values of a coded variable X:",   # description of task or issue of the question
##     Titel = "Question_Freq",     # number or content of the question
##     Question = NULL,
##     Points = 3,     # number of points can be choosed depending on degree of difficulty, for example
##     tol = 0,        # should be set to zero in this case
##     codes = c("red","yellow","green","blue","purple","orange","brown","black","white","chocolate1","royalblue"),
##     Ncodes = sample(5:7,1), # the number of different codings
##     N = sample(c(40,50,60,70,80),1), # the number of observations
##     iter = i,     # number of different questions that should be generated
##     varQ = 1
## )

### German Version of type 4)
NumQ_Freq_DE <- function(Text,Question,Points,Titel,tol,iter,codes,Ncodes,N,varQ="random"){
  N <- sample(seq(N[1],N[2],10),1)
  elements <- sample(codes,Ncodes,replace=F)
  X <- sample(elements,N,replace=T)

  if(varQ!="random") {variation.question <- varQ}
  if(varQ=="random") variation.question <- sample(1:2,1)
  Multiple.Questions <- c("absolute Häufigkeit","relative Häufigkeit")

  freq <- table(X)

  Item <- sample(1:length(freq),1)
  bgap <- Question
  Question <- paste("Insgesamt liegen ", N, " Beobachtungen vor. Bitte ermitteln Sie die ",Multiple.Questions[variation.question]," für X = ",names(freq[Item]),".", sep="")

  Answer <- function(x,type,Item){

    abs_freq <- table(x)[[Item]]
    rel_freq <- table(x)[[Item]]/N

    switch(type,
        Q1 = abs_freq,
        Q2 = rel_freq
    )
  }
  Answer <- Answer(X,c("Q1","Q2")[variation.question],Item)



  if(varQ==1) {
    y			<- matrix(round(freq/N,4),nrow=1)
    tab 		<- matrix(NA,ncol=(length(y)+1),nrow=2)
    tab[-1,-1] 	<- y
    tab[,1] 	<- c("Ausprägung","relative Häufigkeit")
    tab[1,-1]	<- names(freq)
  } else {
    tab <- matrix(NA,ncol=(N/2),nrow=2)
    tab[1,] <- X[1:(N/2)]
    tab[2,] <- X[((N/2)+1):N]
  }


  return(
      Question(Type="Numeric", Text=Text, Tab=tab, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=sprintf("%g",round(c(Answer*(1-tol),Answer*(1+tol)),4)),Points=Points)
  )
}

### 5)
NumQ_EmpDist_DE <- function(Text,Question,Points,Titel,Tab,No,values,iter,tol,extended){

  x <- sample(values,No,replace=F)
  sort.x <- sort(x)
  y <- getprobs(1,No,0.1)
  cum.y <- cumsum(y)

  Image <- tempfile(pattern = "file", tmpdir = tempdir())
  jpeg(filename= Image, quality = 100, width = 672, height = 671)
  ecdf4MQ <- function(x,y){
    yaxis<-c(0,y)
    xaxis <- x
    plot(stepfun(x,yaxis),vertical=F, main="Empirische Verteilungsfunktion", do.p=F, xlim=c(0,2), ylab="F(x)", xlab="Promillegehalt im Blut",col=2)
    #axis(1,at=seq(0,2.4,by=0.2))
    #axis(2,at=seq(0,1,by=0.1))
    points(xaxis,yaxis[-length(yaxis)], cex=1.5, pch=1, col=1)
    points(xaxis,yaxis[-1], cex=1.5, pch=20, col=1)
  }
  ecdf4MQ(sort.x,cum.y)
  dev.off()

  if(Tab==TRUE){
    tab <- matrix(NA,ncol=length(x)+1,nrow=2)
    tab[1,] <- c("Promillewerte",sort.x)
    tab[2,] <- c("relative Häufigkeiten",y)
  } else {
    tab <- NULL
  }

  if (extended == TRUE) {ext <- sample(c(1,2),1)} else {ext <- 1}

  if (ext == 1) {
    type<- sample(c("mehr als","höchstens"),1)
    value<- sample(values,1)
    while(value < sort.x[1]) {
      value<- sample(values,1)
    }
    Question <- paste("Wie hoch ist der Anteil der Stundenten, deren Alkoholgehalt",type,value,"Promille beträgt?")
    sort.x.value <- sort(c(sort.x,value))

    Answer <- ifelse(is.element(value,sort.x),cum.y[match(value,sort.x.value)],cum.y[match(value,sort.x.value)-1])
    if(type=="mehr als"){Answer <- 1-Answer}
  }else{
    type<- c("mehr als","höchstens")
    value<- sample(values,2,replace=F)
    sort.value<- sort(value)
    while(sort.value[1] < sort.x[1]) {
      value<- sample(values,2,replace=F)
      sort.value<- sort(value)
    }

    Question <- paste("Wie hoch ist der Anteil der Stundenten, deren Alkoholgehalt",type[1],sort.value[1], "und", type[2],sort.value[2], "Promille beträgt?")

    sort.x.value.high <- sort(c(sort.x,sort.value[2]))
    sort.x.value.low <- sort(c(sort.x,sort.value[1]))

    Answer.high <- ifelse(is.element(sort.value[2],sort.x),cum.y[match(sort.value[2],sort.x.value.high)],cum.y[match(sort.value[2],sort.x.value.high)-1])
    Answer.low <- ifelse(is.element(sort.value[1],sort.x),cum.y[match(sort.value[1],sort.x.value.low)],cum.y[match(sort.value[1],sort.x.value.low)-1])
    Answer <- Answer.high - Answer.low
  }

  return(
      Question(Type="Numeric", Text=Text, Tab=tab, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=c(Answer-tol,Answer+tol),Points=Points, Image=GetBase64(Image),ImageCoord=NULL)
  )
}

NumQ_Loc <- function(Text,Question=NULL,varQ,Points,tol,Titel,iter,x,Info,rate=NULL){
  n        <- length(x)
  #variation.question <- sample(1:5,1)
  variation.question <- varQ
  Multiple.Questions <- c("das arithmetische Mittel","den Modus","den Median","das geometrische Mittel", "das harmonische Mittel")

  if(is.null(Question)==TRUE){
  Question <- paste("Bitte berechnen Sie ",Multiple.Questions[variation.question],"für die gegebenen Werte.")
    }

  answer  <- function(x,type){
    mean.x   <- mean(x)
    mode.x   <- names(which.max(table(x))[1])
    median.x <- median(x)
    geom.x   <- prod(x)^(1/n)
    harm.x   <- n/sum(1/x)

    switch(type,
        Q1 = mean.x,
        Q2 = mode.x,
        Q3 = median.x,
        Q4 = geom.x,
        Q5 = harm.x)
    }
  Answer <- answer(x,c("Q1","Q2","Q3","Q4","Q5")[variation.question])

  if(is.null(rate)==FALSE) {
    y <- 1+x/100
    pAnswer <- answer(y,c("Q1","Q2","Q3","Q4","Q5")[variation.question])
    Answer <- pAnswer - 1
  }
  Tab <- matrix(NA,ncol=n+1,nrow=1)
  Tab[1,] <- c(Info,x)
  
#   Text <- c(Text, "Runden Sie ihr Ergebnis, falls nötig, auf 4 Nachkommastellen.")

  return(
      Question(Type="Numeric", Text=Text, Tab=Tab, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=sprintf("%g",round(c(Answer*(1-tol),Answer*(1+tol)),4)),Points=Points)
  )
}

NumQ_Cla <- function(Text,Question=NULL,Points,tol,Titel,iter,Infos,N,borders,varQ){
  classes		<- length(borders)-1
  n	 		<- as.numeric(table(sample(1:classes,size=N,replace=T)))
  p	 		<- n/N
  Tab         <- matrix(NA,ncol=2,nrow=classes+1)
  Tab[1,]     <- Infos
  Tab[-1,1]   <- sapply(1:classes, function(j) paste(borders[j],"bis unter",borders[j+1]))
  Tab[-1,2]   <- n
  xprime      <- (borders[1:classes]+borders[2:(classes+1)])/2
  xprimebar   <- sum(xprime*n)/N
  s2          <- sum(p*xprime^2) - xprimebar^2
  multQ		<- c("das arithmetische Mittel","die Varianz")
  Question    <- paste("Bitte berechnen Sie",multQ[varQ],".  Runden Sie, falls nötig, ihr Ergebnis auf 4 Nachkommastellen.",
                       "Hinweis: Auch bei den Zwischenrechnungen auf 4 Nachkommastellen runden.")
  Answer      <- c(xprimebar,s2)[varQ]

  return(
      Question(Type="Numeric", Text=Text, Tab=Tab, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=sprintf("%g",round(c(Answer*(1-tol),Answer*(1+tol)),4)),Points=Points)
  )
}

## QuestionPool <- sapply(1:1000, function(i) NumQ_Cla(
##                     Text     = "Eine Erhebung beim Casting für Triers Next Top–Model ergab folgende Tabelle",
##                     Points   = 0.4,
##                     Titel    = "DS.K3.NumQ.005.",
##                     tol      = 0.01,
##                     iter     = i,
##                     Infos    = c("Größe in cm","Anzahl Bewerber"),
##                     N        = 1000,
##                     borders  = c(155,160,165,170,175,185,190),
##                     varQ     = 1
##             ))

####################################################
#NumQ_Loc(
#	Text = "Von einer Schulklasse seien die folgenden Körpergrößen (in cm) bekannt:",
#	varQ = 1,
#	Points = 0.1,
#	tol = 0.002,
#	Titel = "Question_Loc",
#	iter = 1,
#	x = sample(120:160, 25, T) # has to be numeric
#		)

NumQ_GiniDeu <- function(Text,Question,Points,tol,Titel,iter,N,class.borders,min.steps,Infos,sampProbs){
  probC <- sampProbs[,sample(1:4,1)]
  classes <- length(class.borders)-1
  n <- as.numeric(table(sample(1:classes,size=N,replace=T,prob=probC))) # number of elements within the classes (see more information on function "getprobs" below) -> must sum up to N
  x <- cbind(NA,length(classes))
  for(i in 1:classes){
    x[i] <- sum(sample(seq(class.borders[i],class.borders[i+1],10),n[i],replace=TRUE))
  }
  u <- cumsum(n/N)
  v <- cumsum(x/sum(x))
  gini <- sum(u[-length(u)] * v[-1]) - sum(u[-1] * v[-length(v)])
  Answer <- gini

  Tab <- matrix(NA,ncol=3,nrow=classes+1)
  Tab[1,] <- Infos
  Tab[-1,1] <- sapply(1:classes, function(j) paste(class.borders[j],"bis unter",class.borders[j+1]))
  Tab[-1,2] <- n
  Tab[-1,3] <- x
  return(
      Question(Type="Numeric", Text=Text, Tab=Tab, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=sprintf("%g",round(c(Answer*(1-tol),Answer*(1+tol)),4)),Points=Points)
  )
}

# Variationskoeffizient
NumQ_VC <- function(Text,Question=NULL,Points,tol,Titel,iter,xbar,Infos,Names){

  n        <- length(xbar)
  s        <- sapply(1:n, function(i) sample(seq(0.1,0.5,0.025)*xbar[i],1))
  varcoef  <- s/xbar
  MultQ    <- c("größten", "kleinsten")
  varQ     <- sample(1:2,1)
  Question <- paste("Bitte geben Sie den", MultQ[varQ], "Variationskoeffizienten für die folgenden Werte an. Runden Sie, falls nötig, das Ergebnis auf 4 Nachkommastellen. Hinweis: Lösungen in Prozentdarstellung werden nicht akzeptiert.")

  Answer <- c(max(varcoef),min(varcoef))[varQ]
  Tab <- matrix(NA,ncol=3,nrow=n+1)
  Tab[1,] <- c(Infos,"[tex]\\overline{x}[/tex]","[tex]s^{\\ast}[/tex]")
  Tab[-1,1] <- Names
  Tab[-1,2] <- xbar
  Tab[-1,3] <- s


  return(
      Question(Type="Numeric", Text=Text, Tab=Tab, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=sprintf("%g",round(c(Answer*(1-tol),Answer*(1+tol)),4)),Points=Points)
  )
}

## QP <- sapply(1:100, function(i) NumQ_VC(
##                     Text = "Ein deutscher Chemiekonzern produziert weltweit. Dabei gilt für die Mittelwerte [tex]\\overline{x}[/tex] und Standardabweichungen [tex]s^{\\ast}[/tex] der Löhne folgendes:",
##                     Points = 0.4,
##                     tol = 0.005,
##                     Titel = "DS.K3.NumQ.010.",
##                     iter = i,
##                     xbar = sample(seq(2000,12000,50),8),
##                     Infos = "Länder",
##                     Names = c("Frankreich","China","Ägypten","Indonesien", "USA", "Albanien", "Russland", "Usbekistan")
##             )
## )


NumQ_MVSd <- function(Text,Question=NULL,Points,tol,Titel,iter,x,varQ){

  n        <- length(x)
  MultQ    <- c("das arithmetische Mittel","die Varianz","die Standardabweichung")
  Question <- paste("Bitte berechnen Sie",MultQ[varQ],"für die folgenden Werte. Runden Sie, falls nötig, das Ergebnis auf 4 Nachkommastellen. Hinweis: Auch bei den Zwischenrechnungen auf 4 Nachkommastellen runden.")
  answer <- function(x,type){

    mean <- mean(x)
    variance <- var(x) * (n-1)/n
    sd <- sqrt(variance)

    switch(type,
        Q1 = mean,
        Q2 = variance,
        Q3 = sd
    )
  }
  Answer <- answer(x,c("Q1","Q2","Q3")[varQ])
  Tab <- matrix(NA,ncol=n+1,nrow=1)
  Tab[1,] <- c("Beobachtungen",x)

  return(
      Question(Type="Numeric", Text=Text, Tab=Tab, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=sprintf("%g",round(c(Answer*(1-tol),Answer*(1+tol)),4)),Points=Points)
  )
}

## QuestionPool <- sapply(1:100, function(i) NumQ_MVSd(
##                     Text = "Ein Gruppe von Trierer Metereologen misst an 25 aufeinanderfolgenden Tagen die Temperatur in der Negev-Wüste.",
##                     Points = 0.4,
##                     tol = 0.01,
##                     Titel = "DS.K3.NumQ.007.",
##                     iter = i,
##                     x = sample(seq(30,45,by=0.1),25,replace=T),
##                     varQ = 3
##             )
## )

NumQ_subPI <- function(Text, Question = NULL, Points, tol, Titel, iter, weights, subindMAT, years=c(2010,2011)){
  subind <- subindMAT[,sample(1:ncol(subindMAT),1)]
  n <- length(weights)
  normweights <- weights/sum(weights)
  nyears <- length(years)
  subinds <- cbind(subind, round(sapply(1:n, function(j) subind[j]*sample(seq(0.85,1.15,0.05),1)),1))
  s <- sample(1:nyears,1)
  Answer <- sum(normweights * subinds[,s] )/100
  Question <- paste("Berechnen Sie aus den gegebenen Daten einen zusammenfassenden Preisindex für das Jahr",years[s],". Hinweis: Lösungen in Prozentdarstellung werden nicht akzeptiert.")
  Tab <- matrix(NA, ncol=nyears+2,nrow=n+1)
  Tab[1,] <- c("Untergruppe", "Gewichtung in Promille", sapply(1:nyears, function(j) paste("Teilindex",years[j], "in %")))
  Tab[-1,1] <- 1:n
  Tab[-1,2] <- weights
  Tab[-1,3:4] <- subinds

  return(Question(Type = "Numeric", Text = Text, Tab = Tab, Titel = paste(Titel, sprintf("%05d", iter), sep = ""),
          Question = Question, Answer = sprintf("%g", round(c(Answer * (1 - tol), Answer * (1 + tol)), 4)), Points = Points))
}

## QP <- sapply(1:100, function(i) NumQ_subPI(
##                     Text = "Das statistische Bundesamt hat folgende Teilindizes berechnet:",
##                     Points = 0.2,
##                     tol = 0.005,
##                     Titel = "DS.K4.NumQ.001.",
##                     iter=i,
##                     weights = sample(1:10000/100,5),
##                     subindMAT = cbind(c(102.5, 96.3, 114.7, 100.6, 98.9), c(97.9, 102.4, 108.9, 110.2, 105.0), c(96.8, 101.5, 92.7, 101.1, 105.2),c(103.1, 102.5, 104.7, 109.1, 100.6))
##             )
## )

NumQ_Ind <- function(Text, Question = NULL, Points, tol, Titel, iter, indMAT, years, base = c(2005)){
  index <- indMAT[,sample(1:ncol(indMAT),1)]
  n     <- length(index)

  Tab   <- matrix(NA,nrow=n+1,ncol=2)
  Tab[1,] <- c("Jahr", paste("Basis ", base, sep=""))
  Tab[-1,1] <- years
  Tab[-1,2] <- index

  sampFrom <- c(1:5,7:n)
  s <- sample(sampFrom,1)
  b <- sample(sampFrom[sampFrom!=s],1)

  Question <- paste("Berechnen Sie den Indexwert für das Jahr ",years[s], " auf der Basis von ", years[b], ". Hinweis: Für den Indexwert von ", years[b], " auf der Basis von ", years[b], " würden Sie 100 eintragen.", sep="")
  Answer <- index[s]/index[b]*100

  return(Question(Type = "Numeric", Text = Text, Tab = Tab, Titel = paste(Titel, sprintf("%05d", iter), sep = ""),
          Question = Question, Answer = sprintf("%g", round(c(Answer * (1 - tol), Answer * (1 + tol)), 4)), Points = Points))
}


## QP <- sapply(1:100, function(i) NumQ_Ind(
##                     Text = "Die folgende Indexreihe basiert auf dem Jahr 2005:",
##                     Points = 0.2,
##                     tol = 0.001,
##                     Titel = "DS.K4.NumQ.002.",
##                     iter = i,
##                     indMAT = VPIr[,-1],
##                     years = VPIr[,1]
##             )
## )

NumQ_MSE <- function(Text=NULL, Question=NULL, tol, iter, Titel, Points) {
    sig2 <- sample(1:10,1)
    mu <- sample(2:5,1)
    n <- sample(2:6,1)

    T1 <- "Eine Grundgesamtheit sei normalverteilt mit dem Erwartungswert [tex]\\mu=[/tex]  "
    T2 <- " und der Varianz [tex]\\sigma^2=[/tex] "
    T3 <- " ."
    T4 <- " [tex] X_i \\,\\, , i=1,\\ldots,[/tex] "
    T5 <- " seien unabhängige Ziehungen aus dieser Grundgesamtheit. Es soll [tex]Y=\\sum\\limits_{i=1}^"
    T6 <- " X_i [/tex] als Schätzfunktion zur Schätzung des Parameters [tex]\\mu[/tex] verwendet werden."

    Text1 <- paste(T1,mu,T2,sig2,T3,sep="")
    Text2 <- paste(T4,n,T5,n,T6,sep="")

    Text <- c(Text1,Text2)

    Question <- "Bestimmen Sie den mittleren quadratischen Fehler [tex]MSE(Y)[/tex]."

    BIAS <- (n-1)*mu
    VAR  <- n*sig2

    Sol <- BIAS^2 + VAR
    return(Question(Type = "Numeric", Text = Text, Tab = NULL, Titel = paste(Titel, sprintf("%05d", iter), sep = ""),
                    Question = Question, Answer = sprintf("%g", round(c(Sol * (1 - tol), Sol * (1 + tol)), 4)), Points = Points))

}

## QP <- sapply(1:100, function(i) NumQ_MSE(
##                     tol = 0.01,
##                     iter = i,
##                     Titel = "IS.K4.NumQ.001.",
##                     Points = 0.5
##             )
## )

NumQ_ML <- function(Text,Question,Points,Titel,iter,tol,Distr=c("binomial","exponential"),x){
    distr <- match.arg(Distr)
    n <- length(x)

    Tab <- matrix(nr=2,nc=n+1)
    Tab[,1] <- c("[tex]i[/tex]","[tex]x_i[/tex]")
    Tab[1,-1] <- 1:n
    Tab[2,-1] <- x

    if(distr=="binomial") {
        Sol <- sum(x)/n
        Answer <- round(c(Sol * (1 - tol), Sol * (1 + tol)), 4)
        Answer[Answer<0] <- 0

    } else
    if(distr=="exponential"){

        Sol <- n/sum(x)

        Answer <- round(c(Sol * (1 - tol), Sol * (1 + tol)), 4)
        Answer[Answer<0] <- 0

    } else
        stop("Distribution must be either binomial or exponential")

    return(Question(Type = "Numeric", Text = Text, Tab = Tab, Titel = paste(Titel, sprintf("%05d", iter), sep = ""),
                    Question = Question, Answer = sprintf("%g", Answer), Points = Points))

}

## QP <- sapply(1:100, function(i) NumQ_ML(
##                     Text = "Folgende Tabelle gibt unabhängige Realistationen einer exponentialverteilten Zufallsvariablen an:",
##                     Question = "Geben Sie den Maximum-Likelihood Schätzer [tex]\\hat{\\lambda}[/tex] an.",
##                     Points = 0.2,
##                     Titel = "IS.K4.NumQ.002.",
##                     tol = 0.01,
##                     iter = i,
##                     Distr = "exponential",
##                     x = sample(seq(5,20,0.25),sample(7:12,1),T)
##             )
## )

#######################################################################################################################################################
#
# 		NUMERIC GAPS QUESTIONS
#
#######################################################################################################################################################



### 1) Numerical gaps question: Calculation of the OLS-coefficients of a simple regression model


NumGapsQ_Regression_coefficients <- function(Text,Question,Points,tol,Titel,iter,x,fun){
  y <- fun(x)
  reg <- lm(y~x)
  alpha <- round(coef(reg)[1],4)
  beta <- round(coef(reg)[2],4)
  n<-length(y)

  Answer <- matrix(NA, ncol=3, nrow=2,byrow=FALSE)
  Answer[1,] <- sprintf("%g",round(c(alpha*(1-tol),alpha,alpha*(1+tol)),4))
  Answer[2,] <- sprintf("%g",round(c(beta*(1-tol),beta,beta*(1+tol)),4))

  Tab <- matrix(NA,ncol=n+1,nrow=3)
  Tab[1,] <- c("i",1:n)
  Tab[2,] <- c("X",x)
  Tab[3,] <- c("Y",y)
  return(
    Question(Type="NumericGaps", Text=Text, Tab=Tab, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=Points)
  )
}

#### Example for function call:

#NumGapsQ_Regression_coefficients(

#    Text = "Let X and Y be two metric variables. Y is considered to be dependent on X. The following table provides information on the values of the variables:",   # Description of task or issue of the question
#    Titel = "Question_Reg_coeff_",     # Number or content of the question
#    Quest = "Please caculate the coefficients for the simple regression model [tex]\\hat{y}_i = \\text{Wert}_1 + \\text{Wert}_2\\cdot x_i[/tex] by using the method of least squares.",   # Formulation of a concrete question (Questions and/or Text can contain LaTeX elements).
#    Points = c(5,3),     # The achievable number of points must be specified as vectors. The length of these vectors must be the number of match-missing gaps. Each missing value can get the same or different number of points.
#    tol = 0.001,     # Range of tolerance to take into account possible rounding errors (can also be set to cero)
#    iter = x,      # Number of different questions that should be generated
#    x = sample(seq(0,40,1),10,replace=T),     # Vector of values for x variable
#    fun=function(x)round(rnorm(length(x),x*runif(1,-10,10),3),0)    # Function to generate y out of x.
#)

# Further comments:
# -
# -





### 2) Numerical gaps question: Contigency table (2x2)


NumGapsQ_ContigencyTable <- function(Text,Question,Points,tol,Titel,iter,data){

  # Information on characteristics
  n<-sum(data)
  variation.question <- sample(1:2,1)
  Multiple.Questions <- c("absolute","relative")
  Question <- paste("Determine the",Multiple.Questions[variation.question]," values of the marginal distributions of the frequency table.")
  #data <- matrix(NA)
  if(variation.question==1){
    data <- rbind(data,apply(data,2,sum))
    data <- cbind(data,apply(data,1,sum))
    value <- c(data[1:2,dim(data)[2]],data[dim(data)[1],1:2])
    Answer<-cbind(sprintf("%g",round(value*(1-tol),4)),sprintf("%g",value),sprintf("%g",round(value*(1+tol),4)))
    data[1:2,dim(data)[2]] <- paste("[tex]\\text{Value}_{",paste(1:2),"}[/tex]",sep="")
    data[dim(data)[1],1:2] <- paste("[tex]\\text{Value}_{",paste(3:4),"}[/tex]",sep="")
  }
  if(variation.question==2){
    data <- rbind(data,round(apply(data,2,sum)/n,4))
    data <- cbind(data,round(apply(data,1,sum)/n,4))
    value <- c(data[1:2,dim(data)[2]],data[dim(data)[1],1:2])
    Answer<-cbind(sprintf("%g",round(value*(1-tol),4)),sprintf("%g",value),sprintf("%g",round(value*(1+tol),4)))
    data[1:2,dim(data)[2]] <- paste("[tex]\\text{Value}_{",paste(1:2),"}[/tex]",sep="")
    data[dim(data)[1],1:2] <- paste("[tex]\\text{Value}_{",paste(3:4),"}[/tex]",sep="")
    data[dim(data)[1],dim(data)[2]] <- 1
  }
  Tab <- matrix(NA,ncol=dim(data)[2]+1,nrow=dim(data)[1]+1)
  Tab[1,] <- c("X | Y","y1","y2",ifelse(variation.question==1,"[tex]n_{j \\cdot}[/tex]","[tex]p_{j \\cdot}[/tex]"))
  Tab[2,] <- c("x1",data[1,])
  Tab[3,] <- c("x2",data[2,])
  Tab[4,] <- c(ifelse(variation.question==1,"[tex]n_{\\cdot k}[/tex]","[tex]p_{\\cdot k}[/tex]"),data[3,])

  return(
    Question(Type="NumericGaps", Text=Text, Tab=Tab, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=Points(Answer))
  )
}

### Example for function call:

#NumGapsQ_ContigencyTable(

#    Text = "Consider the two variables X and Y. You can find several missing values in the following frequency table, which need to be filled in:",   # Description of task or issue of the question
#    Titel = "Question_ContTab_",     # Number or content of the question
#    Question = Question,    # Question ist specified within the function, because it contains further random arguments
#    Points = function(A)rep(1,dim(A)[1]),     # The achievable number of points must be specified as function of the Answer matrix. The length of these vectors must be the number of match-missing gaps. Each missing value can get the same or different number of points.
#    tol = 0,     # Range of tolerance to take into account possible rounding errors (can also be set to NULL)
#    iter = x,      # Number of different questions that should be generated
#    data = matrix(1:4,2,2)     # enter data in matrix
#)

# Further comments:
# -

# 3) Numerical gaps question: Working table

NumGapsQ_WorkingTable <- function(Text,Question,Points,tol,Titel,iter,object,N,upborders,elements,gaps){
  classes		<- length(upborders)
  borders 	<- c(0,upborders)

  options(scipen=10)

  nr <- classes
  nc <- length(elements)

  shorts 	<- c("[tex]n_j[/tex]","[tex]p_j[/tex]","[tex]F_j (x)[/tex]","[tex]d_j[/tex]","[tex]h_j[/tex]")
  n 		<- getprobs(N,classes,5)
  p 		<- n/N
  f 		<- cumsum(p)
  d 		<- (borders[-1] - borders[-length(borders)])
  h 		<- round(p/d,7)
  h 		<- sprintf("%4.7f",h)

  data 		<- cbind(n,p,f,d,h)
  namdata 	<- dimnames(data)[[2]]
  in.Elem     <- namdata %in% elements
  data 		<- data[,in.Elem]
  shorts 	    <- shorts[in.Elem]
  colnames(data) <- shorts

  choice 	<- sample(1:length(data),gaps,F)

  A			 <- as.numeric(data[choice])
  AMAT         <- matrix(rep(A,3),nrow=gaps)
  AMAT[,1]     <- AMAT[,1]*(1-tol)
  AMAT[,3]     <- AMAT[,3]*(1+tol)
  Answer       <- AMAT
  data[choice] <- sapply(1:gaps, function(i) paste("[tex]\\text{Lücke",i,"}[/tex]",sep=""))

  tab         <- matrix(NA, ncol=nc+1, nrow=nr+1)
  tab[1,1]    <- object
  tab[-1,1]  <- sapply(1:nr, function(j) paste(borders[j],"b.u.",borders[j+1]))
  tab[1,-1]   <- sapply(1:nc, function(j) colnames(data)[j])
  tab[-1,-1]  <- data

  return(
      Question(Type="NumericGaps", Text=Text, Tab=tab, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=rep(Points,gaps))
  )
}

### Example for Function Call:
## QuestionPool <- sapply(1:1000, function(i) NumGapsQ_WorkingTable(
##                     Text				= "Während des Tutoriums haben Sie es nicht geschafft, alle Werte der Arbeitstabelle in Ihre Unterlagen zu übertragen.",
##                     Question			= "Geben Sie die fehlenden Werte in der Tabelle an. Runden Sie Ihre Ergebnisse falls nötig auf 7 Nachkommatsellen.",
##                     Points				= 0.1,
##                     Titel				= "DS.K2.NumGapsQ.001.",
##                     tol					= 0.01,
##                     iter				= i,
##                     object				= "Einkommen in Euro",
##                     N 					= 200,
##                     upborders 			= c(650,950,1200,1500,3000),
##                     elements			= c("n","p","f","d","h"),
##                     gaps				= 4
##
##             ))

NumGapsQ_EmpDist_DE <- function(Text=NULL,Question,Points,Titel,Tab,No,values,iter){

  x <- sample(values,No,replace=F)
  sort.x <- sort(x)
  y <- getprobs(1,No,0.1)
  cum.y <- cumsum(y)

  Image <- tempfile(pattern = "file", tmpdir = tempdir())
  jpeg(filename= Image, quality = 100, width = 672, height = 671)
  ecdf4MQ <- function(x,y){
    yaxis<-c(0,y)
    xaxis <- x
    plot(stepfun(x,yaxis),vertical=F, main="Empirische Verteilungsfunktion", do.p=F, xlim=c(0,2), ylab="F(x)", xlab="Promillegehalt im Blut",col=2)
    #axis(1,at=seq(0,2.4,by=0.2))
    #axis(2,at=seq(0,1,by=0.1))
    points(xaxis,yaxis[-length(yaxis)], cex=1.5, pch=1, col=1)
    points(xaxis,yaxis[-1], cex=1.5, pch=20, col=1)
  }
  ecdf4MQ(sort.x,cum.y)
  dev.off()

  if(Tab==TRUE){
    tab <- matrix(NA,ncol=length(x)+1,nrow=2)
    tab[1,] <- c("Promillewerte",sort.x)
    tab[2,] <- c("relative Häufigkeiten",y)
  } else {
    tab <- NULL
  }
  varq <- sample(1:2,1)
  type<- c("mehr als","höchstens")

  # First gap
  value1<- sample(values,1)
  while(value1 < sort.x[1]) {
    value1<- sample(values,1)
  }
  Q1 <- paste("Wie hoch ist der Anteil der Stundenten, deren Alkoholgehalt",type[varq],value1,"Promille beträgt?")
  sort.x.value1 <- sort(c(sort.x,value1))
  A1 <- ifelse(is.element(value1,sort.x),cum.y[match(value1,sort.x.value1)],cum.y[match(value1,sort.x.value1)-1])
  if(varq==1){A1 <- 1-A1}

  # Second gap
  value2<- sample(values,2,replace=F)
  sort.value2<- sort(value2)
  while(sort.value2[1] < sort.x[1]) {
    value2<- sample(values,2,replace=F)
    sort.value2<- sort(value2)
  }
  Q2 <- paste("Ermitteln Sie zudem den Anteil der Stundenten, deren Alkoholgehalt",type[1],sort.value2[1], "und", type[2],sort.value2[2], "Promille beträgt?")

  sort.x.value.high <- sort(c(sort.x,sort.value2[2]))
  sort.x.value.low <- sort(c(sort.x,sort.value2[1]))

  A2.high <- ifelse(is.element(sort.value2[2],sort.x),cum.y[match(sort.value2[2],sort.x.value.high)],cum.y[match(sort.value2[2],sort.x.value.high)-1])
  A2.low <- ifelse(is.element(sort.value2[1],sort.x),cum.y[match(sort.value2[1],sort.x.value.low)],cum.y[match(sort.value2[1],sort.x.value.low)-1])
  A2 <- A2.high - A2.low

  A <- matrix(rep(c(A1,A2),3),nrow=2)
  A[,1] <- A[,1]-0.005
  A[,3] <- A[,3]+0.005
  Answer <- A
  Question <- c(Q1,Q2)
  return(  Question(Type="NumericGaps", Text=Text, Tab=tab, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=Points, Image=GetBase64(Image),ImageCoord=NULL)
  )
}
NumGapsQ_group <- function(Text,Question=NULL,Points,tol,Titel,iter,names,Infos,Woerter,x,varQ){
  n  <- length(x)
  nam <- sample(names,n)
  groups <- sample(c(1,2),n-2,replace=T)
  groups <- c(1,2,groups)
  mean.g <- tapply(x,groups,mean)
  sum2.g <- tapply(x,groups,function(x) sum(x^2))
  len.g  <- table(groups)
  var.g  <- sum2.g/len.g - mean.g^2
  mean.t <- mean(x)
  var.t  <- 1/n*sum(sum2.g) - mean.t^2
  sd.g   <- sqrt(var.g)
  sd.t   <- sqrt(var.t)

  Tab       <- matrix(NA,3,nrow=n+1)
  Tab[1,]   <- c(Infos,"Gruppenzugehörigkeit")
  Tab[-1,1] <- nam
  Tab[-1,2] <- x
  Tab[-1,3] <- groups

  MultQ    <- c("das arithmetische Mittel","die Varianz","die Standardabweichung")

  Q1 <- paste("Bitte berechnen Sie", MultQ[varQ], Woerter[2],"für Gruppe 1.")
  Q2 <- paste("Bitte berechnen Sie", MultQ[varQ],  Woerter[2],"für Gruppe 2.")
  Q3 <- paste("Ermitteln Sie außerdem noch", MultQ[varQ],  Woerter[2], "für alle", Woerter[1], ".")
  Question <- c(Q1,Q2,Q3)
  Text <- c(Text, "Runden Sie, falls nötig, die Ergebnisse auf 4 Nachkommastellen. Hinweis: Auch bei den Zwischenrechnungen auf 4 Nachkommastellen runden.")
  
  Res.g <- cbind(mean.g,var.g,sd.g)
  Res.t <- c(mean.t,var.t,sd.t)

  A1 <- Res.g[1,varQ]
  A2 <- Res.g[2,varQ]
  A3 <- Res.t[varQ]

  A1gaps <- round(c(A1*(1-tol),A1,A1*(1+tol)),4)
  A2gaps <- round(c(A2*(1-tol),A2,A2*(1+tol)),4)
  A3gaps <- round(c(A3*(1-tol),A3,A3*(1+tol)),4)

  Answer <- rbind(A1gaps,A2gaps,A3gaps)

  return(
      Question(Type="NumericGaps", Text=Text, Tab=Tab, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=Points)
  )
}

## QP <- sapply(1:100, function(i) NumGapsQ_group(
##                     Text = "Eine medizinische Fakultät untersucht das Körpergewicht von Studenten, die gemäß ihres Schokoladenkonsums in zwei Gruppen unterteilt wurden:",
##                     Points = rep(0.2,3),
##                     tol = 0.0025,
##                     Titel = "DS.K3.NumGapsQ.002.",
##                     iter = i,
##                     names = c("Markus", "Eric", "Tobias", "Florian", "Britta", "Anja", "Helene", "Steffi", "Andrea", "Torsten", "Caro", "Thomas", "Susanne", "Robert", "Elena", "Julia"),
##                     Infos = c("Student","Körpergewicht in kg"),
##                     Woerter = c("Studenten","des Körpergewichts in kg"),
##                     x = sample(50:110,12),
##                     varQ = 2
##             )
## )


NumGapsQ_Lorenz <- function (Text, Question=NULL, Points, Titel, sampProbsExt, iter, Infos, Plu, tol, type="Lorenzkurve") {
  sampProbs <- sampProbsExt[,sample(1:8,4)]
  S <- sample(1:4,1)
  F <- seq(1,4,1)[-S]
  Correct <- sampProbs[,S]
  Wrong   <- sampProbs[,-S]
  n       <- length(Correct)

  SPsort  <- apply(sampProbs,2,sort)
  SPcum   <- apply(SPsort,2,cumsum)

  SPdecr  <- apply(sampProbs,2,function(x) sort(x,decreasing=T))
  SPalph  <- apply(SPdecr,2,function(x) cumsum(x)/sum(x))

  u <- 1:n/n
  v <- SPcum[,S]
  gini <- sum(u[-n] * v[-1]) - sum(u[-1] * v[-n])

  lor4MQ <- function(x, num, type) {
    if(type=="Lorenzkurve"){
      plot(0:n/n, c(0,x), main = paste(type, num), xlab="Anteil Merkmalsträger", ylab="Anteil Merkmalsbetrag",type="l",xlim=c(0,1),ylim=c(0,1))
      points(0:n/n, c(0,x), pch=19)
      lines(c(0,1),c(0,1))
    }
    else {plot(0:n, c(0,x), main = paste(type, num), xlab="Anzahl Merkmalsträger", ylab="Anteil Merkmalsbetrag",type="l",xlim=c(0,n),ylim=c(0,1))
      points(0:n, c(0,x), pch=19)
      lines(c(0,n),c(0,1))
    }
  }


  Image <- tempfile(pattern = "file", tmpdir = tempdir())
  jpeg(filename= Image, quality = 100, width = 672, height = 671)

  if(type=="Lorenzkurve"){
    par(mfrow = c(2, 2))
    lor4MQ(SPcum[,1], 1, type)
    lor4MQ(SPcum[,2], 2, type)
    lor4MQ(SPcum[,3], 3, type)
    lor4MQ(SPcum[,4], 4, type)
  }

  if(type=="Konzentrationskurve"){
    par(mfrow = c(2, 2))
    lor4MQ(SPalph[,1], 1, type)
    lor4MQ(SPalph[,2], 2, type)
    lor4MQ(SPalph[,3], 3, type)
    lor4MQ(SPalph[,4], 4, type)
  }

  dev.off()


  tab <- matrix(NA,nrow=2,ncol=n+1)
  tab[1,]    <- c(Infos[1],1:n)
  tab[2,1]   <- Infos[2]

  if(type=="Lorenzkurve") {
    tab[2,-1]  <- sample(Correct)*25000
  }

  if(type=="Konzentrationskurve") {
    tab[2,-1]  <- sample(Correct)*25000
  }

  Q1 <- paste("Welcher",type,"entsprechen die",Plu[1],"der Tabelle?. Wichtig: Tragen Sie für",type, "1 eine 1, für",type,"2 eine 2, für", type,"3 eine 3 und für",type,"4 eine 4 ein.")
  Q2 <- "Berechnen Sie bitte den Gini-Koeffizient für die in der Tabelle angegebenen Werte."
  Q3 <- paste("Angenommen die Einkommen aller",Plu[2],"erhöhen sich um 1000 Euro. Wie verändert sich der Gini-Koeffizient? Wichtig: Kennzeichnen Sie einen erhöhten Gini-Koeffizient mit einer 1, einen niedrigeren Gini-Koeffizienten mit einer 2 und einen unveränderten Gini-Koeffizienten mit einer 3.")
  Q4 <- paste("Angenommen die Einkommen aller",Plu[2],"sinken um 10 Prozent. Wie verändert sich der Gini-Koeffizient? Wichtig: Kennzeichnen Sie einen erhöhten Gini-Koeffizient mit einer 1, einen niedrigeren Gini-Koeffizienten mit einer 2 und einen unveränderten Gini-Koeffizienten mit einer 3.")
  Q5 <- paste("Angenommen der reichste ",Infos[1],"transferiert einen positiven Betrag an den ärmsten Bewohner. Wie verändert sich der Gini-Koeffizient? Wichtig: Kennzeichnen Sie einen erhöhten Gini-Koeffizient mit einer 1, einen niedrigeren Gini-Koeffizienten mit einer 2 und einen unveränderten Gini-Koeffizienten mit einer 3.")

  Question <- c(Q1,Q2,Q3,Q4,Q5)

  A1 <- rep(S,3)
  A2 <- c(gini*(1-tol),gini,gini*(1+tol))
  A3 <- rep(2,3)
  A4 <- rep(3,3)
  A5 <- rep(2,3)

  Answer <- rbind(A1,A2,A3,A4,A5)

  return(Question(Type = "NumericGaps", Text = Text, Tab = tab,
          Titel = paste(Titel, sprintf("%05d", iter), sep = ""),
          Question = Question, Answer = Answer, Points = Points, Image = GetBase64(Image), ImageCoord = NULL))
}

# hier eine recht hohe Toleranz wählen
NumGapsQ_WT_Gini <-function (Text,Question,Points,tol,Titel,iter,N,class.borders,gaps,sampProbs) {
  options(scipen=10)
  probC <- sampProbs[,sample(1:4,1)]
  classes <- length(class.borders)-1
  n <- as.numeric(table(sample(1:classes,size=N,replace=T,prob=probC)))
  x_vj <- cbind(NA,length(classes))
  for(i in 1:classes){
    x_vj[i] <- sum(sample(seq(class.borders[i],class.borders[i+1],10),n[i],replace=TRUE))
  }

  p <- round(n/N,4)
  u <- round(cumsum(n/N),4)
  v <- round(cumsum(x_vj/sum(x_vj))   ,4)

  shorts <- c("[tex]x_j[/tex]", "[tex]n_j[/tex]", "[tex]\\sum\\nolimits_v^{n_j}x_{v,j}[/tex]", "[tex]v_j^{\\prime}[/tex]",
      "[tex]p_j[/tex]", "[tex]u_j^{\\prime}[/tex]")

  x <- sapply(1:classes, function(i) paste(class.borders[i], "bis unter", class.borders[i+1]))
  data <- cbind(x_vj, v, p, u)
  posCho <- 1:length(data)
  choice <- sample(posCho[-c(classes*2,classes*4)], gaps, F)
  A <- as.numeric(data[choice])
  AMAT <- matrix(rep(A, 3), nrow = gaps)
  AMAT[, 1] <- AMAT[, 1] * (1 - tol)
  AMAT[, 3] <- AMAT[, 3] * (1 + tol)
  Answer <- AMAT
  data[choice] <- sapply(1:gaps, function(i) paste("[tex]\\text{Lücke",
            i, "}[/tex]", sep = ""))

  Data <- cbind(x,n,data)
  nrtab <- nrow(data) + 2
  tab <- matrix(NA, ncol = ncol(Data), nrow = nrtab)
  tab[1, ] <- shorts
  tab[2:(classes+1),] <- Data
  tab[nrtab,1] <- "[tex]\\sum[/tex]"
  tab[nrtab,2] <- N
  tab[nrtab,3] <- sum(x_vj)
  tab[nrtab,5] <- 1
  tab[nrtab,c(4,6)] <- ""
  return(Question(Type = "NumericGaps", Text = Text, Tab = tab,
          Titel = paste(Titel, sprintf("%05d", iter), sep = ""),
          Question = Question, Answer = Answer, Points = rep(Points,
              gaps)))
}

## QP <- sapply(1:100, function(i) NumGapsQ_WT_Gini(
##                     Text = "Leider konnten Sie im letzten Tutorium bei der Aufgabe zum Gini-Koeffizienten nicht alle Werte mitschreiben:",
##                     Question = "Vervollständigen Sie bitte die Lücken in der folgenden Arbeitstabelle. Hinweis: Runden Sie die Ergebisse, falls nötig, auf 4 Nachkommastellen.",
##                     Points = rep(0.1,4),
##                     tol = 0.025,
##                     Titel = "DS.K3.NumGapsQ.004.",
##                     iter = i,
##                     N = 400,
##                     class.borders = c(0,100,500,1000,1500,2000,3000),
##                     gaps = 4,
##                     sampProbs = cbind(c(0.3,0.2,0.2,0.15,0.05,0.1),c(0.15,0.2,0.25,0.1,0.15,0.15),c(0.1,0.25,0.15,0.15,0.25,0.1),c(0.25,0.2,0.1,0.25,0.15,0.05),c(0.1,0.2,0.15,0.2,0.15,0.2))
##             )
## )


NumGapsQ_Kon <- function(Text, Question=NULL, Points, Titel, iter, x, tol, Infos){
  xsort <- sort(x,decreasing=T)
  mx    <- mean(x)
  n     <- length(x)
  C_al  <- cumsum(xsort)/(n*mx)
  C_bar <- mean(C_al)
  Herf  <- sum((x/(n*mx))^2)
  MultQ <- c("die durchschnittliche Konzentrationsrate [tex]\\overline{C}[/tex].", "den Herfindahl-Index [tex]K_H[/tex].")
  Q1 <- paste("Bitte berechnen Sie", MultQ[1])
  Q2 <- paste("Bitte berechnen Sie", MultQ[2])
  Hinweis <- "Runden Sie, falls nötig, die Ergebnisse auf 4 Nachkommastellen. Hinweis: Auch bei den Zwischenrechnungen auf 4 Nachkommastellen runden."
  Question <- c(Q1,Q2)
  Text <- c(Text, Hinweis)


  Tab <- matrix(NA,ncol=n+1,nrow=2)
  Tab[1,] <- c(Infos[1],1:n)
  Tab[2,] <- c(Infos[2],x)

  A <- c(C_bar,Herf)
  AMAT <- matrix(rep(A, 3), nrow = 2)
  AMAT[, 1] <- AMAT[, 1] * (1 - tol)
  AMAT[, 3] <- AMAT[, 3] * (1 + tol)
  Answer <- round(AMAT,4)


  return(
      Question(Type="NumericGaps", Text=Text, Tab=Tab, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=Points)
  )
}

## QP <- sapply(1:100, function(i) NumGapsQ_Kon(
##                     Text = "Eine Untersuchung des Bundeskartellamts zur Marktmacht von Molkereien brachte folgendes Ergebnis zu Tage:",
##                     Points = c(0.3,0.2),
##                     Titel =  "DS.K3.NumGapsQ.005.",
##                     iter = i,
##                     x = sample(seq(100,500,5),10),
##                     tol = 0.005,
##                     Infos = c("Molkerei", "Umsatz (Mio. Euro)"),
##             )
## )

NumGapsQ_Obs <- function(Text=NULL, Question=NULL, Points, Titel, iter, xbar, tol, n, n.add, s2, dev){
  x.ext <- sample(sample(round(seq(xbar - dev, xbar + dev,1)),n.add))
  n.tot <- n + n.add
  mxneu <- mean(x.ext)
  mx    <- n/n.tot*xbar+sum(x.ext)/n.tot
  s2n   <- sum(x.ext^2)/n.add - mxneu^2
  s2tot <- (n*(s2 + (xbar - mx)^2) + n.add*(s2n + (mxneu - mx)^2))/n.tot
  vcoef <- sqrt(s2tot)/mx

  Text <- paste("Von der Kommunalwahl in einer Großstadt sind auf der Basis von n=", n, "Wahlbezirken folgende Kennzahlen zur Anzahl der abgegebenen Stimmen bekannt: arithmetisches Mittel [tex]\\overline{x}[/tex] =", xbar, "und empirische Varianz:[tex]s^{\\ast 2}[/tex]=",s2,". Weitere Stimmenanzahlen aus", n.add, "zusätzlichen Wahlbezirken wurden später noch bekannt (siehe Tabelle)")

  MultQ <- c("das arithmetische Mittel", "die Varianz", "den Variationskoeffizienten")
  Q1 <- paste("Bitte berechnen Sie", MultQ[1], "für alle", n.tot, "Wahlbezirke.")
  Q2 <- paste("Bitte berechnen Sie", MultQ[2], "für alle", n.tot, "Wahlbezirke.")
  Q3 <- paste("Bitte berechnen Sie", MultQ[3], "für alle", n.tot, "Wahlbezirke.")
  Hinweis <- "Runden Sie, falls nötig, die Ergebnisse auf 4 Nachkommastellen. Hinweis: Auch bei den Zwischenrechnungen auf 4 Nachkommastellen runden. Lösungen in Prozentdarstellung werden nicht akzeptiert."
  Question <- c(Q1,Q2,Q3)
  Text <- c(Text,Hinweis)

  Tab <- matrix(NA,ncol=n.add+1,nrow=1)
  Tab[1,1] <- "Nachträglich gemeldete Werte"
  Tab[1,-1]  <- x.ext

  A <- c(mx,s2tot,vcoef)
  AMAT <- matrix(rep(A, 3), nrow = 3)
  AMAT[, 1] <- AMAT[, 1] * (1 - tol)
  AMAT[, 3] <- AMAT[, 3] * (1 + tol)
  Answer <- round(AMAT,4)


  return(
      Question(Type="NumericGaps", Text=Text, Tab=Tab, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=Points)
  )
}

## QP <- sapply(1:100, function(i) NumGapsQ_Obs(
##                     Points = c(0.2,0.2,0.1),
##                     Titel = "DS.NumGapsQ.006.",
##                     iter = i,
##                     xbar = sample(seq(4000,5000,5),1),
##                     dev = 500,
##                     tol = 0.1,
##                     n = sample(10:20,1),
##                     n.add = sample(3:5,1),
##                     s2 = sample(seq(12000,15000,20),1)
##             )
## )

NumGapsCla <- function(Text,Question=NULL,Points,tol1,tol2,Titel,iter,Infos,N,borders){
  classes   <- length(borders)-1
  n         <- as.numeric(table(sample(1:classes,size=N,replace=T)))
  p         <- n/N
  Tab       <- matrix(NA,ncol=2,nrow=classes+1)
  Tab[1,]   <- Infos
  Tab[-1,1] <- sapply(1:classes, function(j) paste(borders[j],"bis unter",borders[j+1]))
  Tab[-1,2] <- n
  xprime    <- (borders[1:classes]+borders[2:(classes+1)])/2
  xprimebar <- sum(xprime*n)/N
  s2        <- sum(p*xprime^2) - xprimebar^2

  Q1 <- "Bitte berechnen Sie das geeignete arithmetische Mittel."
  Q2 <- "Berechnen Sie außerdem noch die geeigenete Varianz."
  Hinweis <- "Runden Sie, falls nötig, die Ergebnisse auf 4 Nachkommastellen. Hinweis: Auch bei den Zwischenrechnungen auf 4 Nachkommastellen runden."
  Question <- c(Q1,Q2)
  Text <- c(Text,Hinweis)
  A1 <- round(c(xprimebar*(1-tol1),xprimebar,xprimebar*(1+tol1)),4)
  A2 <- round(c(s2*(1-tol2), s2, s2*(1+tol2)),4)
  Answer <- rbind(A1,A2)

  return(
      Question(Type="NumericGaps", Text=Text, Tab=Tab, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=Points)
  )
}

## QuestionPool <- sapply(1:100, function(i) NumGapsCla(
##                     Text   = "Ein Elektrofachgeschäft hat die in den letzten 4 Monaten verkauften Waschmaschinen in 5 Preisklassen eingeordnet.",
##                     Points = c(0.4,0.1),
##                     Titel  = "DS.K3.NumGapsQ.001.",
##                     tol1   = 0.01,
##                     tol2   = 0.025,
##                     iter   = i,
##                     Infos  = c("Preis in Euro","Anzahl verkaufter Waschmaschinen"),
##                     N      = 300,
##                     borders= c(200,400,500,600,800,1000)
##             ))

NumGapsQ_PI <- function (Text, Question = NULL, Points, tol, Titel, iter, qalt,  palt, Index = c("Laspeyres", "Paasche", "Fisher"),
    type = c("price", "quantity"), ngaps = 6, display = "quantities") {
  n <- length(qalt)
  qneu <- round(sapply(1:n, function(j) sample((0.5 * qalt[j]):(1.5 * qalt[j]), 1)))
  pneu <- round(sapply(1:n, function(j) sample(seq(0.5 * palt[j], 1.5 * palt[j], 0.05), 1)), 2)

  pLa <- Laspeyres(palt, pneu, qalt, qneu, type = "price")
  qLa <- Laspeyres(palt, pneu, qalt, qneu, type = "quantity")
  pPa <- Paasche(palt, pneu, qalt, qneu, type = "price")
  qPa <- Paasche(palt, pneu, qalt, qneu, type = "quantity")
  pFi <- Fisher(palt, pneu, qalt, qneu, type = "price")
  qFi <- Fisher(palt, pneu, qalt, qneu, type = "quantity")

  A <- matrix(rep(c(pLa, pPa, pFi, qLa, qPa, qFi), 3), ncol = 3)
  A[, 1] <- A[, 1] * (1 - tol)
  A[, 3] <- A[, 3] * (1 + tol)

  ninds <- length(Index)
  ntype <- length(type)

  NamI <- sapply(1:ninds, function(i) paste(" nach ", Index[i], sep = ""))
  typI <- c("Preisindex", "Mengenindex")
  MultQ <- sapply(1:ntype, function(m) paste("Bitte berechnen Sie den ", typI[m], NamI, sep = ""))

  inds <- c("Laspeyres", "Paasche", "Fisher") %in% Index
  types <- c("price", "quantity") %in% type


  TF = matrix(inds,ncol=1)%*%matrix(types,nrow=1)
  comp <- as.numeric(sapply(1:3, function(i) paste(TF[i,])))

  Ans <- A[comp==1,]


  Quest <- sapply(1:length(MultQ), function(j) paste(MultQ[j], ".",sep=""))
  Hinweis <- "Runden Sie das Ergebnis, falls nötig, auf vier Nachkommastellen."
  Question <- Quest
  Text <- c(Text, Hinweis)

  Answer <- Ans
  Tab <- matrix(NA, ncol = 5, nrow = n + 1)

  if(display=="quantities") {
    Tab[1, ] <- c("Gut", "[tex]q_{i0}[/tex]", "[tex]p_{i0}[/tex]", "[tex]q_{i1}[/tex]", "[tex]p_{i1}[/tex]")
    Tab[-1, 1] <- 1:n
    Tab[-1, -1] <- cbind(qalt, palt, qneu, pneu)
  }

  else {
    Tab[1, ] <- c("Gut", "Umsatz in Periode 0", "Umsatz in Periode 1", "Preis in Periode 0", "Preis in Periode 1")
    Tab[-1, 1] <- 1:n
    Tab[-1, -1] <- cbind(qalt*palt, qneu*pneu, palt, pneu)
  }

  return(Question(Type = "NumericGaps", Text = Text, Tab = Tab,
          Titel = paste(Titel, sprintf("%05d", iter), sep = ""),
          Question = Question, Answer = Answer, Points = Points))
}

## QP <- sapply(1:100, function(i) NumGapsQ_PI(
##                     Text = "Sie erhalten folgende Information zu den Umsätzen und Preisen verschiedener Güter zu Basisperiode 0 und Berichtsperiode 1:",
##                     Points = rep(0.2,6),
##                     tol = 0.01,
##                     Titel = "DS.K4.NumGapsQ.008.",
##                     iter = i,
##                     qalt = sample(seq(10,100,5),5),
##                     palt = sample(3:20,5),
##                     display = "revenues"
##             )
## )

NumGapsQ_2dFreq <- function(Text, Question = NULL, Points, tol, Titel, iter, MATlist,ngaps=2){
  rmat <- sample(1:3,1)
  MAT  <- MATlist[[rmat]]
  ncla <- dim(MAT)[2]-1
  gaps <- sample(1:ncla,2)
  core <- MAT
  
  core[1,gaps[1]] <- "[tex]\\text{Lücke 1}[/tex]"
  core[2,gaps[2]] <- "[tex]\\text{Lücke 2}[/tex]"
  
  Q1 <- "1. Berechnen Sie den fehlenden Wert bei "
  Q2 <- "2. Berechnen Sie den fehlenden Wert bei "
  Q3 <- paste("3. Berechnen Sie die Wahrscheinlichkeit, dass ein arbeitsloser Mann ", colnames(MAT)[gaps[1]], " Jahre alt ist.", sep="")
  Q4 <- paste("4. Berechnen Sie die Wahrscheinlichkeit, dass eine arbeitslose Frau ", colnames(MAT)[gaps[2]], " Jahre alt ist.", sep="")
  
  Question <- c(Q1, Q2, Q3, Q4)
  
  A1 <- MAT[1,gaps[1]]
  A2 <- MAT[2,gaps[2]]
  A3 <- MAT[1,gaps[1]]/MAT[1,ncla+1]
  A4 <- MAT[2,gaps[2]]/MAT[2,ncla+1]
  
  A <- matrix(c(A1,A2,A3,A4),ncol=3,nrow=4)
  A[1:2,1] <- A[1:2,1]*(1-tol/100)
  A[1:2,3] <- A[1:2,3]*(1+tol/100)
  A[3:4,1] <- A[3:4,1]*(1-tol)
  A[3:4,3] <- A[3:4,3]*(1+tol)
  
  Answer <- A
  
  Tab <- matrix(NA, ncol=ncla+2, nrow=4)
  Tab[1,] <- c("Erwerbslose", colnames(MAT))
  Tab[-1,1] <- rownames(MAT)
  Tab[-1,-1] <- core
  
  return(Question(Type = "NumericGaps", Text = Text, Tab = Tab, Titel = paste(Titel, sprintf("%05d", iter), sep = ""),
                  Question = Question, Answer = Answer, Points = Points))
  
}
## QP <- sapply(1:100, function(i) NumGapsQ_2dFreq(
##                     Text = "Folgende Tabelle gibt die Anzahl der Erwerbslosen in Deutschland an (in tsd):",
##                     Points = rep(0.1,4),
##                     tol = 0.01,
##                     Titel = "DS.K5.NumGapsQ.001.",
##                     iter = i,
##                     MATlist = ALOlist
##             )
## )

NumGapsQ_biFreq <- function(Text, Question=NULL, Points, Titel, iter, tol, XYlist, Xborders, Yinfos){
  s  <- sample(1:2,1)
  XY <- XYlist[[s]]
  n  <- sum(XY)
  dims <- dim(XY)
  Tab <- matrix(NA, ncol=dims[2]+1, nrow=dims[1]+1)
  Tab[1,] <- c("Rendite", Yinfos)
  Tab[-1,1] <- sapply(1:dims[1], function(i) paste(Xborders[i], "% b.u.", Xborders[i+1], "%"))
  Tab[-1,-1] <- XY
  
  sy <- sample(1:length(Yinfos),2,replace=T)
  sx <- sample(1:(length(Xborders)-1),2,replace=T)
  print(sx)
  print(sy)
  
  Q1 <- paste("Wie hoch ist der Anteil der Finanzprodukte, die höchstens ein ",Yinfos[sy[1]], " und mindestens eine Rendite von ",Xborders[sx[1]],"% haben?",sep="")
  Q2 <- paste("Wie hoch ist der Anteil der Finanzprodukte, die mindestens ein ",Yinfos[sy[2]], " und mindestens eine Rendite von ",Xborders[sx[2]],"% haben?",sep="")
  
  Question <- c(Q1,Q2)
  
  A1 <- sum(XY[sx[1]:dims[1],1:sy[1]])/n
  A2 <- sum(XY[sx[2]:dims[1],sy[2]:dims[2]])/n
  
  A <- matrix(c(A1,A2),ncol=3,nrow=2)
  A[,1] <- A[,1] - tol
  A[,3] <- A[,3] + tol
  A[A<0] <- 0
  A[A>1] <- 1
  
  Answer <- A
  print(Answer)
  
  
  return(Question(Type = "NumericGaps", Text = Text, Tab = Tab, Titel = paste(Titel, sprintf("%05d", iter), sep = ""),
                  Question = Question, Answer = Answer, Points = Points))
}
## QP <- sapply(1:100, function(i) NumGapsQ_biFreq(
##                     Text = "Folgende Tabelle gibt den Zusammenhang zwischen Rendite und Rating für eine Reihe von Finanzprodukten wieder:",
##                     Points = rep(0.2,2),
##                     tol = 0.01,
##                     Titel = "DS.K5.NumGapsQ.002.",
##                     iter = i,
##                     XYlist = XYlist,
##                     Yinfos = c("sehr schlechtes Rating", "schlechtes Rating", "mittleres Rating", "gutes Rating", "sehr gutes Rating"),
##                     Xborders = c(0,3,4,5,6,15)
##             )
## )

NumGapsQ_NomMeasures <- function(Text, Question = NULL, Points, tol, Titel, iter,Xinfo,Yinfo,n,ngaps=5){
  nx <- length(Xinfo)
  ny <- length(Yinfo)
  Vals <- table(c(1:(nx*ny),sample(1:(nx*ny),n-nx*ny,replace=T)))
  X <- matrix(Vals, nrow=nx)

  dims <- dim(X)
  XC <- cbind(X,rowSums(X))
  XCR <- rbind(XC,colSums(XC))

  Xnull <- t(sapply(1:dims[1], function(i) sapply(1:dims[2], function(j) XCR[i,dims[2]+1]*XCR[dims[1]+1,j]/n)))
  Chi2 <- sum((X-Xnull)^2/Xnull)
  K <- sqrt(Chi2/(n+Chi2))
  M <- min(dims)
  Kmax <- sqrt((M-1)/M)
  Kstar <- K/Kmax
  Phi <- sqrt(Chi2/n)
  V   <- sqrt(Chi2/(n*(M-1)))

  A <- matrix(c(Chi2,K,Kstar,Phi,V),ncol=3,nrow=ngaps)
  A[,1] <- A[,1] * (1-tol)
  A[,3] <- A[,3] * (1+tol)

  Answer <- A

  Measures <- c("den [tex]\\chi^2[/tex]-Wert.", "den Kontingenzkoeffizienten [tex]\\text{K}[/tex].", "den normierten Kontingenzkoeffizienten [tex]\\text{K}_{*}[/tex].",
      "Pearson's [tex]\\Phi[/tex].", "Cramer's Kontingenzkoeffizienten.")

  Question <- sapply(1:ngaps, function(m) paste("Bitte berechnen Sie ", Measures[m], sep = ""))
  Hinweis <- "Runden Sie die Ergebnisse, falls nötig, auf vier Nachkommastellen."
  
  
  Text <- c(Text,Hinweis)

  Tab <- matrix(NA,nrow=nx+1,ncol=ny+1)
  Tab[1,] <- c("", Yinfo)
  Tab[-1,1] <- Xinfo
  Tab[-1,-1] <- X

  return(Question(Type = "NumericGaps", Text = Text, Tab = Tab, Titel = paste(Titel, sprintf("%05d", iter), sep = ""),
          Question = Question, Answer = Answer, Points = Points))
}

## QP <- sapply(1:100, function(i) NumGapsQ_NomMeasures(
##                     Text = "Die folgende Tabelle enthält Informationen zum Fachbereich und Geschlecht von Trierer Studierenden:",
##                     Points = c(0.4,rep(0.1,4)),
##                     tol = 0.1,
##                     Titel = "DS.K5.NumGapsQ.003.",
##                     iter = i,
##                     Xinfo = c("FB I", "FB II", "FB III", "FB IV", "FB V", "FB VI"),
##                     Yinfo = c("männlich", "weiblich"),
##                     n = sample(100:200,1)
##             )
## )

NumGapsQ_Indep <- function(Text,Question=NULL,Titel,tol,iter,Points,XRVlist, YRVlist){
  s <- sample(1:length(XRVlist),1)
  XRV <- XRVlist[[s]]
  YRV <- YRVlist[[s]]
  n <- sum(XRV)

  MAT <- matrix(XRV/n,ncol=1)%*%matrix(YRV/n,nrow=1)
  MAT1 <- cbind(MAT,rowSums(MAT))
  MAT2 <- rbind(MAT1,colSums(MAT1))

  NotMiss <- c(1,5,11,12)
  Enum <- 1:12
  Miss <- Enum[!Enum%in%NotMiss]

  T <- MAT2
  T[Miss] <- sapply(1:8, function(i) paste ("[tex]\\text{Lücke", i, "}[/tex]"))

  Tab <- matrix(NA,nrow=4,ncol=5)
  Tab[1,] <- c("","[tex]\\text{y}_1[/tex]", "[tex]\\text{y}_2[/tex]", "[tex]\\text{y}_3[/tex]","[tex]\\text{RV X}[/tex]")
  Tab[-1,1] <- c("[tex]\\text{x}_1[/tex]", "[tex]\\text{x}_2[/tex]", "[tex]\\text{RV Y}[/tex]")
  Tab[-1,-1] <- T

  A <- matrix(MAT2[Miss],ncol=3,nrow=8)
  A[,1] <- A[,1] *(1-tol)
  A[,3] <- A[,3] *(1+tol)

  Answer <- A
  Question <- "Vervollständigen Sie diese Tabelle unter der Annhame, die beiden Merkmale seien unabhängig."

  return(Question(Type = "NumericGaps", Text = Text, Tab = Tab, Titel = paste(Titel, sprintf("%05d", iter), sep = ""),
          Question = Question, Answer = Answer, Points = Points))

}

## QP <- sapply(1:5, function(i) NumGapsQ_Indep(
##                     Text = "Folgende Kontingenztabelle mit relativen Häufigkeiten sei gegeben:",
##                     Titel = "DS.K5.NumGapsQ.004.",
##                     Points = rep(0.1,8),
##                     tol = 0.01,
##                     iter = i,
##                     XRVlist = list(c(10,30), c(20,20), c(15,25), c(20,10), c(25,55)),
##                     YRVlist = list(c(20,15,5), c(5,15,20), c(10,15,15), c(20,5,5), c(33,20,25))
##
##             )
## )

NumGapsQ_Spearman <- function(Text, Question = NULL, Titel, iter, tol, Points, n){
  y <- sample(20:200,n)
  x <- sample(150:195,n)

  rankCor <- cor(x,y,method="spearman")
  Tab <- matrix(NA, nrow=n+1,ncol=3)
  Tab[1,] <- c("Person", "[tex]\\text{x}[/tex]", "[tex]\\text{y}[/tex]")
  Tab[-1,1] <- 1:n
  Tab[-1,2] <- x
  Tab[-1,3] <- y

  Q1 <- "Berechnen Sie den Rangkorrelationskoeffizienten nach Spearman [tex]\\text{r}_{sp}[/tex] zwischen der Leistung in der Statistik-Klausur und der Körpergröße. Hinweis: Ordnen Sie der Person mit der höchsten Körpergröße und der besten Statistik-Klausur jeweils Rang 1 zu."
  Q2 <- "Berechnen Sie [tex]\\text{r}_{sp}[/tex] erneut für den Fall, dass der Person mit der kleinsten Körpergröße und der schlechtesten Statistik-Klausur jeweils Rang 1 zugewiesen wird."
  Q3 <- "Dürfte man den Rangkorrelationskoeffizienten auch berechnen, wenn statt der Punkte in der Klausur nur die Noten bekannt wären? Kennzeichnen Sie eine richtige Aussage mit einer 1, eine falsche Aussage mit einer 2."
  Hinweis <- "Runden Sie bei Lücken 1 und 2 ihr Ergebnis auf vier Nachkommastellen, falls nötig."
  
  Text <- c(Text,Hinweis)

  Question <- c(Q1,Q2,Q3)
  A12 <- rankCor
  A3 <- 1

  A <- matrix(c(A12,A12,A3),nrow=3,ncol=3)
  A[1:2,1] <- A[1:2,1] - tol
  A[1:2,3] <- A[1:2,3] + tol
  A[A>1] <- 1
  A[A< -1] <- -1

  Answer <- A

  return(Question(Type = "NumericGaps", Text = Text, Tab = Tab, Titel = paste(Titel, sprintf("%05d", iter), sep = ""),
          Question = Question, Answer = Answer, Points = Points))

}

## QP <- sapply(1:100, function(i) NumGapsQ_Spearman(
##                     Text = "Folgende Tabelle gibt die Körpergröße, Variable [tex]\\text{x}[/tex], und die erzielten Punkte in der Statistik-Klausur, [tex]\\text{y}[/tex], von 10 Personen an.",
##                     Titel = "DS.K5.NumGapsQ.005.",
##                     iter = i,
##                     tol = 0.01,
##                     Points = c(0.3,0.1,0.1),
##                     n = 10
##             )
## )

NumGapsQ_PIq <- function (Text, Question = NULL, Points, tol, Titel, iter, qalt,  palt, ngaps = 2) {
  n <- length(qalt)
  qneu <- round(sapply(1:n, function(j) sample((0.5 * qalt[j]):(1.5 * qalt[j]), 1)))
  pneu <- round(sapply(1:n, function(j) sample(seq(0.5 * palt[j], 1.5 * palt[j], 0.05), 1)), 2)

  pLa <- Laspeyres(palt, pneu, qalt, qneu, type = "price")
  pPa <- Paasche(palt, pneu, qalt, qneu, type = "price")


  A <- matrix(rep(c(pLa, pPa), 3), ncol = 3)
  A[, 1] <- A[, 1] * (1 - tol)
  A[, 3] <- A[, 3] * (1 + tol)

  Q1 <- "Berechnen Sie den Preisindex nach Laspeyres ([tex]\\text{Lücke 1}[/tex])."
  Q2 <- "Berechnen Sie den Preisindex nach Paasche ([tex]\\text{Lücke 2}[/tex])."
  Hinweis <- "Runden Sie das Ergebnis, falls nötig, auf vier Nachkommastellen."
  Question <- c(Q1,Q2,Hinweis)

  Answer <- A
  Tab <- matrix(NA, ncol = 5, nrow = n + 1)

  Tab[1, ] <- c("Gut", "Umsatz in Periode 0", "Umsatz in Periode 1", "Preis in Periode 0", "Preis in Periode 1")
  Tab[-1, 1] <- 1:n
  Tab[-1, -1] <- cbind(qalt*palt, qneu*pneu, palt, pneu)

  return(Question(Type = "NumericGaps", Text = Text, Tab = Tab,
          Titel = paste(Titel, sprintf("%05d", iter), sep = ""),
          Question = Question, Answer = Answer, Points = Points))
}

## QP <- sapply(1:100, function(i) NumGapsQ_PIq(
##                     Text = "Sie erhalten folgende Information zu den Umsätzen und Preisen verschiedener Güter zu Basisperiode 0 und Berichtsperiode 1:",
##                     Points = rep(0.2,2),
##                     tol = 0.01,
##                     Titel = "DS.K4.NumGapsQ.010.",
##                     iter = i,
##                     qalt = sample(seq(3,45,1),4),
##                     palt = sample(3:15,4),
##             )
## )

NumGapsQ_Cor <- function(Text,Question=NULL,Titel,Points,tol,iter,n,xrange,Infos,scaleFact){
  x <- sample(xrange,n)
  y <- round(scaleFact*x + rnorm(n,0,5*sd(x)))

  while(length(unique(y)) < n)  y <- round(3*x + rnorm(n,0,5*sd(x)))
  rgCor <- cor(x,y,method="spearman")
  bpCor <- cor(x,y)

  Q1 <- "Berechnen Sie den Rangkorrelationskoeffizienten für die vorliegenden Daten."
  Q2 <- "Berechnen Sie den Korrelationskoeffizienten von Bravais-Pearson für die vorliegenden Daten."
  Hinweis <- "Runden Sie das Ergebnis, falls nötig, auf 4 Nachkommastellen."
  Text <- c(Text,Hinweis)

  Question <- c(Q1,Q2)

  A <- matrix(c(rgCor,bpCor),ncol=3,nrow=2)
  A[,1] <- A[,1] - tol
  A[,3] <- A[,3] + tol
  A[A< -1] <- -1
  A[A>1] <- 1

  Answer <- A

  Tab <- matrix(NA,nrow=n+1,ncol=3)
  Tab[1,] <- c("i",Infos)
  Tab[-1,1] <- 1:n
  Tab[-1,2] <- x
  Tab[-1,3] <- y

  return(Question(Type = "NumericGaps", Text = Text, Tab = Tab, Titel = paste(Titel, sprintf("%05d", iter), sep = ""),
          Question = Question, Answer = Answer, Points = Points))

}

## QP <- sapply(1:100, function(i) NumGapsQ_Cor(
##                     Text = "Von den Triathleten des SC Ennepetal-West seien folgende Bestzeiten (in Minuten) bekannt:",
##                     Titel = "DS.K5.NumGapsQ.007.",
##                     tol = 0.01,
##                     iter = i,
##                     Points = rep(0.2,2),
##                     Infos = c("Schwimmen","Laufen"),
##                     xrange = 55:95,
##                     scaleFact=3,
##                     n = 10
##             )
## )

NumGapsQ_CovCor <- function(Text, Question = NULL, Points, Titel, tol, iter, n, mu, sigma){
  require("mvtnorm")
  DAT <- rmvnorm(n,mu,sigma)
  x <- round(DAT[,1],1)
  y <- round(DAT[,2],1)
  
  Q1 <- "Berechnen Sie die Kovarianz [tex]s_{xy}^*[/tex]."
  Q2 <- "Berechnen Sie den Korrelationskoeffizienten [tex]r_{xy}[/tex]."
  Q3 <- "Berechnen Sie das Bestimmheitsmaß [tex]r_{xy}^2[/tex]."
  Hinweis <- "Runden Sie die Ergebnisse, falls nötig, auf 4 Nachkommastellen."
  Question <- c(Q1,Q2,Q3)
  
  A <- matrix(c(cov(x,y)*(n-1)/n,cor(x,y),cor(x,y)^2),nrow=3,ncol=3)
  A[,1] <- A[,1]*(1-tol*sign(A[,2]))
  A[,3] <- A[,3]*(1+tol*sign(A[,2]))
  
  Text <- c(Text,Hinweis)
  
  Answer <- A
  
  Tab <- matrix(NA,ncol=3,nrow=n+1)
  Tab[1,] <- c("[tex]i[/tex]","[tex]x[/tex]","[tex]y[/tex]")
  Tab[-1,1] <- 1:n
  Tab[-1,2] <- x
  Tab[-1,3] <- y
  
  return(Question(Type = "NumericGaps", Text = Text, Tab = Tab, Titel = paste(Titel, sprintf("%05d", iter), sep = ""),
                  Question = Question, Answer = Answer, Points = Points))
  
}

## QP <- sapply(1:100, function(i) NumGapsQ_CovCor(
##                     Text = "Die nachfolgende Tabelle gibt die Messungen für zwei metrische Variablen an:",
##                     Points = c(0.2,0.2,0.1),
##                     Titel = "DS.K5.NumGapsQ.008.",
##                     tol = 0.015,
##                     iter = i,
##                     n = 5,
##                     mu = c(25,30),
##                     sigma = matrix(c(7,4,4,5),ncol=2)
##             )
## )

# muss noch überarbeitet werden
## NumGapsQ_LM <- function(Text, Question = NULL, Points, Titel, tol, iter, n, mu, sigma){
##     require("mvtnorm")
##     DAT <- rmvnorm(n,mu,sigma)
##     x <- round(DAT[,1],1)
##     y <- round(DAT[,2],1)
##
##     mod <- lm(y~x)
##     Q1 <- "Berechnen Sie den Steigungsparameter [tex]b[/tex] mittels KQ-Methode ([tex]\\text{Lücke 1}[/tex])."
##     Q2 <- "Berechnen Sie den Achsenabschnitt [tex]a[/tex] mittels KQ-Methode ([tex]\\text{Lücke 2}[/tex])."
##     Hinweis <- "Runden Sie die Ergebnisse, falls nötig, auf 4 Nachkommastellen."
##     Question <- c(Q1,Q2,Hinweis)
##
##     A <- matrix(c(coef(mod)[2],coef(mod)[1]),nrow=2,ncol=3)
##     A[,1] <- A[,1]*(1-tol)
##     A[,3] <- A[,3]*(1+tol)
##
##     Answer <- A
##
##     Tab <- matrix(NA,ncol=3,nrow=n+1)
##     Tab[1,] <- c("[tex]i[/tex]","[tex]x[/tex]","[tex]y[/tex]")
##     Tab[-1,1] <- 1:n
##     Tab[-1,2] <- x
##     Tab[-1,3] <- y
##
##     return(Question(Type = "NumericGaps", Text = Text, Tab = Tab, Titel = paste(Titel, sprintf("%05d", iter), sep = ""),
##                     Question = Question, Answer = Answer, Points = Points))
##
## }
##
## QP <- sapply(1:100, function(i) NumGapsQ_LM(
##                     Text = "Sie bereiten sich auf die anstehende Statistik-Klausur vor und bitten einen Freund, ihnen eine Aufgabe zur linearen Regression zu stellen. Der Freund erstellt folgende Tabelle:",
##                     Points = rep(0.2,2),
##                     Titel = "DS.K5.NumGapsQ.009.",
##                     tol = 0.005,
##                     iter = i,
##                     n = 10,
##                     mu = sample(seq(50,80,10),2),
##                     sigma = matrix(c(20,18,18,25),ncol=2)
##             )
## )

NumGapsQ_U_TM <-function(Text=NULL, Question=NULL, Points, tol, Titel, iter, Text1, Text2, Text3){

#Zufallsdefinierter Erwartungswert
  Erw <- sample(1:100,1)

#Zufallszahl
  a <- sample(1:50,1)

#Zufallsdefiniertes x*
  ZZ <- sample(Erw : (Erw + a) ,1)

#Zufallsdefinierter Varianz
  Var <- sample(1:400,1)

#Zufallszahl
  b <- sample(1:10,1)

  Epsilon <- sample(round((sqrt(Var)+1)) : (sqrt(Var)+a),1)
  GrenzeU <- Erw - Epsilon

  if(GrenzeU<=0){
    Epsilon <- sample(round((sqrt(Var)+1)) : (sqrt(Var)+a),1)
    GrenzeU <- Erw - Epsilon
  }
  GrenzeO <- Erw + Epsilon

  A1 <- Erw/ZZ
  A2 <- 1-(Var/Epsilon^2)
  A3 <- 0
  A4 <- 1
  Answer <- matrix(c(A1,A2,A3,A4),ncol=3, nrow=4)
  Answer[,1] <- Answer[,1] -tol
  Answer[,3] <- Answer[,3] +tol


  Text <- paste(Text1,Erw,Text2,Var,Text3,sep="")


  Q1 <- paste("Geben Sie mit Hilfe der Ungleichung von Markov eine Abschätzung für die Bereichswahrscheinlichkeit [tex]W(X\\geq ",ZZ," ) an[/tex].", sep="")
  Q2 <- paste("Geben Sie nun eine Abschätzung für die Wahrscheinlichkeit [tex]W( ",GrenzeU," \\le X \\le ",GrenzeO," )[/tex] mit Hilfe der Ungleichung von Tschebychev an.",sep="")
  Q3 <- paste("Berechnen Sie [tex]W(X= ",a,").[/tex]", sep="")
  Q4 <- "Darf man die Ungleichung von Markov und die Ungleichung von Tschebychev auch zur Abschätzung von Wahrscheinlichkeiten bei diskreten Zufallsvariablen anwenden? Für Ja tragen Sie eine 1 ein und für Nein tragen Sie eine 0 ein."

  Question <- c(Q1,Q2,Q3,Q4)

  return(Question(Type = "NumericGaps", Text = Text, Titel = paste(Titel, sprintf("%05d", iter), sep = ""),
          Question = Question, Answer = Answer, Points = Points))
}

## QP <- sapply(1:100, function(i) NumGapsQ_U_TM(
##                     Text1 = "Von einer stetigen Zufallsvariablen sei lediglich bekannt, dass sie nur nichtnegative Werte annimmt und einen Erwartungswert von ",
##                     Text2 = " sowie eine Varianz von ",
##                     Text3 = " besitzt.",
##                     tol = 0.01,
##                     Titel = "IS.K2.NumGapsQ.005.",
##                     iter = i,
##                     Points = c(0.2, 0.2, 0.1, 0.1)
##             )
## )

NumGapsQ_JointDistMod <- function(Text,Question,Points,Titel,tol,iter,gaps=6){

  # Generierung zufälliger Parameter
  fx1 <- sample(seq(0.2, 0.4, 0.05),1); fx2<- sample(seq(0.2, 0.4, 0.05),1); fx3 <- 1 - fx1 -fx2
  p11 <- fx1 * sample(seq(0.4,0.6,0.1),1); p12 <- 0.2 * fx1; p13 <- fx1 - p11 - p12
  p21 <- fx2 * sample(seq(0.2,0.5,0.1),1); p22 <- 0.4 * fx2; p23 <- fx2 - p21 - p22
  p31 <- fx3 * sample(seq(0.3,0.5,0.1),1); p32 <- 0.4 * fx3; p33 <- fx3 - p31 - p32


  p <- c(p11, p12, p13, p21, p22, p23, p31, p32, p33)
  X  <- rep(1:3, each=3)
  Y  <- rep(1:3, 3)

  # Antworten
  A1 <- sum(p*X)
  A2 <- sum(p*Y)
  A3 <- signif(sum(p*X^2) - A1^2,4)
  A4 <- signif(sum(p*Y^2) - A2^2,4)
  A5 <- signif(sum(p*X*Y) - A1 * A2,4)
  A6 <- signif(A5/(sqrt(A3)*sqrt(A4)),4)

  Werte <- c("E(X)", "E(Y)", "Var(X)", "Var(Y)", "Cov(X,Y)", "Cor(X,Y)")
  Question <- paste("Berechnen Sie ", Werte, ".", sep="")

  tab <- matrix(NA,ncol=4,nrow=4)
  tab[1,] <- c("","Y=1", "Y=2", "Y=3")
  tab[2,] <- c("X=1",p[1:3] )
  tab[3,] <- c("X=2",p[4:6])
  tab[4,] <- c("X=3",p[7:9])

  Text <- c(Text, "Runden Sie Ihre Ergebnisse, falls nötig, auf 5 Nachkommastellen.")

  Answer <- matrix(NA, ncol=3, nrow=gaps,byrow=F)
  Answer[,2] <- round(c(A1,A2,A3,A4,A5,A6),5)
  Answer[,1] <- round(Answer[,2]*(1-tol*sign(Answer[,2])),5)
  Answer[,3] <- round(Answer[,2]*(1+tol*sign(Answer[,2])),5)


  return(
      Question(Type="NumericGaps", Text=Text, Tab=tab, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=Points)
  )
}
## QuestionPool <- sapply(1:100, function(i) NumGapsQ_JointDistMod(
##                     Text = "Die gemeinsame Wahrscheinlichkeitsverteilung von X und Y ist durch folgende Tabelle gegeben:",
##                     Points = rep(0.2,6),
##                     Titel = "IS.K2.NumGapsQ.006.",
##                     tol = 0.01,
##                     iter =i
##             ))

NumGapsQ_FuncRandVar2 <- function(Text,Question,Points,Titel,tol,iter,gaps){

  # Generierung zufälliger Parameter
  EX1 <- sample(seq(40,60,1),1)
  VX1 <- sample(seq(70,95,1),1)
  EX2 <- sample(seq(20,30,1),1)
  VX2 <- sample(seq(35,60,1),1)
  COV <- sample(seq(-30,30,1),1)


  ai <- sample(seq(2,5,1),1)
  bi <- sample(seq(2,4,1),1)

  # Inhaltliche Fragen

  Information <- paste(Text, "[tex]Y = \\frac{1}{",ai,"}\\cdot(\\frac{1}{",bi,"}\\cdot X_1 - X_2)[/tex], mit den folgenden Werten: [tex]E(X1) = ", EX1, "[/tex], [tex]Var(X1) = ", VX1, "[/tex], [tex]E(X2) = ", EX2, "[/tex], [tex]Var(X2) = ", VX2, "[/tex] und [tex]Cov(X1,X2) = ", COV,"[/tex].",sep="")
  Text <- c(Information, "Runden Sie Ihre Ergebnisse, falls nötig, auf 5 Dezimalstellen.")

  Q1 <- "Berechnen Sie den Erwartungswert von Y."
  Q2 <- "Berechnen Sie die Varianz von Y."

  Question <- c(Q1,Q2)

  # Antworten
  A1 <- 1/ai*(1/bi*EX1-EX2)
  A2 <- (1/ai*1/bi)^2*VX1 + (1/ai)^2 *VX2 - 2*(1/ai*(1/ai*1/bi))*COV


  Answer <- matrix(NA, ncol=3, nrow=gaps,byrow=F)
  Answer[,2] <- round(c(A1,A2),5)
  Answer[,1] <- round(Answer[,2]*(1-tol*sign(Answer[,2])),5)
  Answer[,3] <- round(Answer[,2]*(1+tol*sign(Answer[,2])),5)


  return(
      Question(Type="NumericGaps", Text=Text, Tab=NULL, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=Points)
  )
}


## QuestionPool <- sapply(1:100, function(i) NumGapsQ_FuncRandVar2(
##                     Text = "Betrachtet wird die Zufallsvariable ",
##                     Points = c(0.2,0.4),
##                     Titel = "IS.K2.NumGapsQ.007.",
##                     tol = 0.01,
##                     iter = i,
##                     gaps = 2
##             ))

CalculateCI <- function(xbar=NULL, sig2=NULL, S2=NULL, VX=NULL, n, alpha=0.05, prop=NULL, N=NULL,
        Universe=c("normal","arbitrary"), Sigma=c("known", "unknown"), Target=c("mu","EX","sig2","prop"), WoR=FALSE){
    if(is.null(n)) stop ("n is missing")
    univ <- match.arg(Universe)
    sigma <- match.arg(Sigma)
    target <- match.arg(Target)

    if(target=="mu") {
        if(is.null(xbar)) stop("xbar is missing")
        if(univ!="normal") stop("To calculate mu you need the normality assumption")
        if(sigma=="known") {
            if(is.null(sig2)) stop("sig2 is missing")
            DEV <- round(qnorm(1-alpha/2),4)*sqrt(sig2/n)
            return(c(xbar - DEV, xbar + DEV))
        } else {
            if(is.null(S2)) stop("S2 is missing")
            DEV <- round(qt(1-alpha/2, n-1),3) * sqrt(S2/n)
            return(c(xbar - DEV, xbar + DEV))
        }
    } else

    if(target=="sig2"){
        if(is.null("S2")) stop("sig2 is missing")
        if(univ!="normal") stop(" you need the normality assumption")
        lower <- ((n-1)*S2)/round(qchisq(1-alpha/2,n-1),3)
        upper <- ((n-1)*S2)/round(qchisq(alpha/2,n-1),3)
        return(c(lower, upper))
    } else if(target=="EX") {
        if(is.null(xbar)) stop("xbar is missing")
        if(univ=="normal") stop("The distribution should be arbitrary")
        if(WoR) {
            if(is.null(N)) stop("N is missing")
            if(is.null(S2)) stop("S2 is missing")
            DEV <- round(qnorm(1-alpha/2),4) * sqrt(S2/n * (N-n)/(N-1))
            return(c(xbar - DEV, xbar + DEV))
        } else {
            if(sigma=="known") {
                if(is.null(VX)) stop("VX is missing")
                DEV <- round(qnorm(1-alpha/2),4)*sqrt(VX/n)
                return(c(xbar - DEV, xbar + DEV))
            } else {
                if(is.null(S2)) stop("S2 is missing")
                DEV <- round(qnorm(1-alpha/2),4) * sqrt(S2/n)
                return(c(xbar - DEV, xbar + DEV))
            }

        } }else

    if(target=="prop") {
        if(is.null(prop)) stop("prop is missing")
        if(n*prop*(1-prop) <= 9 | prop < 0.1 | prop > 0.9) stop ("normal approximation is not valid")
        DEV <- round(qnorm(1-alpha/2),4)*sqrt(prop * (1-prop)/n)
        return(c(prop - DEV, prop + DEV))
    } else
        stop ("Wrong target")
}

NumGapsQ_CIpoint <- function(Text=NULL, Question=NULL, Points, Titel, iter, tol, x=NULL, xbar = NULL, SD, alpha=.05, N=NULL, n=NULL,
        Sigma=c("known", "unknown"), Target = c("mu","EX"), Info,WoR=FALSE,sampSize=FALSE){
    if(is.null(n)) pest <- T
    else pest <- F
    if(is.null(xbar)) xbar <- mean(x)
    if(pest) n <- length(x)
    target = match.arg(Target)
    sigma = match.arg(Sigma)
    if(target=="mu") {
        dist <- "normal"
        alpha <- 0.05
    }
    else dist <- "arbitrary"

    if(sampSize & n < 200) sampSize<-FALSE

    sig2 <- S2 <- VX <- SD^2

    if(length(alpha)==1) {
        borders <- CalculateCI(xbar=xbar, sig2=sig2, S2=S2, VX=VX, N=N, n=n, alpha=alpha,
                Universe=dist, Sigma=sigma, Target=target, WoR=FALSE)
    } else {
        borders <- sapply(1:length(alpha), function(i) CalculateCI(xbar=xbar, sig2=sig2, S2=S2, VX=VX, N=N, n=n, alpha=alpha[i],
                            Universe=dist, Sigma=sigma, Target=target, WoR=FALSE))
    }


    UGtext <- "Geben Sie die Untergenze des "
    OGtext <- "Geben Sie die Obergenze des "
    text <- rep(c(UGtext, OGtext),length(alpha))
    Alpha <- rep(alpha,each=length(alpha))

    Q <- paste(text, (1-Alpha)*100, "%-Konfidenzintervalls ",  Info[[1]], " an.", sep="")

    Text <- gsub('n=', paste("n=",n,sep=""),Text)
    Text <- gsub('\\\\overline\\{x\\}=', paste("\\\\overline\\{x\\}=",xbar,sep=""),Text)
    Text <- gsub('s=', paste("s=",SD,sep=""),Text)



    if(sampSize) {
        dmax<-floor(min(abs(xbar-borders)))
        d<-sample(round(0.5*dmax):round(0.75*dmax),1)
        alp <- sample(Alpha,1)
        Qsamp <- paste("Ermitteln Sie den notwendigen Stichprobenumfang [tex]n[/tex] für ein ", (1-alp)*100, "%-Konfidenzintervall der Länge [tex]d \\le [/tex] ", d, " .",sep="")

        if(alp==0.05) {
            nstar <- ceiling(4*round(qnorm(1-alp/2),3)^2*SD^2/d^2)
        } else {
            if(alp==0.1) {
                nstar <- ceiling(4*1.645^2*SD^2/d^2)
            } else
                nstar <- ceiling(4*2.575^2*SD^2/d^2)
        }

    }

    if(pest) {
        if(target=="mu") {
            Text <- c(Text,"Sie können von einer normalverteilten Grundgesamtheit ausgehen.","Eine Stichprobe ergab folgende Werte:")
        } else
            Text <- c(Text,"Eine Stichprobe ergab folgende Werte:")
        Tab <- matrix(ncol=2,nrow=n+1)
        Tab[1,] <- c("i", Info[[2]] )
        Tab[-1,1] <- 1:n
        Tab[-1,2] <- x

        Question <- c(paste("Geben Sie einen geeigneten Punktschätzwert ", Info[[1]], " an.", sep=""),Q)
        Answer <- matrix(c(xbar, as.vector(borders)),ncol=3,nrow=length(Question))
        Answer[,1] <- Answer[,1]*(1-sign(Answer[,1])*tol)
        Answer[,3] <- Answer[,3]*(1+sign(Answer[,3])*tol)

        if(sampSize) {
            Question <- c(Question,Qsamp)
            Answer <- rbind(Answer,c(nstar-0.1,nstar,nstar+0.1))
        }


    } else {
        if(target=="mu") {
            Text <- c(Text,"Sie können von einer normalverteilten Grundgesamtheit ausgehen.")
        } else
            Text <- Text
        Tab <- NULL

        Question <- Q
        Answer <- matrix(as.vector(borders), ncol=3, nrow=length(Question))
        Answer[,1] <- Answer[,1]*(1-sign(Answer[,1])*tol)
        Answer[,3] <- Answer[,3]*(1+sign(Answer[,3])*tol)

        if(sampSize) {
            Question <- c(Question,Qsamp)
            Answer <- rbind(Answer,c(nstar-0.1,nstar,nstar+0.1))
        }
    }

    return(Question(Type = "NumericGaps", Text = Text, Tab=Tab, Titel = paste(Titel, sprintf("%05d", iter), sep = ""),
                    Question = Question, Answer = Answer, Points = rep(Points,length(Question))))
}

## QP <- sapply(1:100, function(i) NumGapsQ_CIpoint(
##                     ## Text = "An der Universität Trier sind [tex]N=[/tex] Studierende im Fach BWL eingeschrieben. Das Ministerium interessiert sich für das durchschnittliche Alter und lässt eine Stichprobe vom Umfang [tex]n=[/tex] durchführen. Daraus wurde ein mittleres Alter von [tex]\\overline{x}=[/tex] Jahren bei einer Standardabweichung von [tex]s=[/tex] Jahren ermittelt.",
##                     Text = "Die Marktforschungsabteilung einer Großbank interessiert sich für die Einkommenssituation der Deutschen und erhebt eine Stichprobe von [tex]n=[/tex]. Daraus wurde ein durchschnittliches Einkommen von [tex]\\overline{x}=[/tex] Euro bei einer Standardabweichung von [tex]s=[/tex] Euro ermittelt.",
##                     Points = 0.2,
##                     alpha = c(0.05,0.01),
##                     Titel = "IS.K4.NumGapsQ.003.",
##                     tol = 0.005,
##                     iter = i,
##                     xbar = sample(seq(20000,50000,1000),1),
##                     Info = list("für das durchschnittliche Einkommen","Proband"),
##                     n = sample(seq(300,500,25),1),
##                     SD=sample(seq(2000,5000,250),1),
##                     Sigma = sample(c("known","unknown"),1),
##                     Target = sample(c("mu","EX"),1),
##                     sampSize=TRUE
##             )
## )

NumGapsQ_CIprop <- function(Text1, Text2, Text3, Question=NULL, Points, Titel, iter, prop, alpha=.05, n,
        Sigma="unknown", Target = "prop", Distribution="arbitrary",Info,WoR=FALSE){

    sigma <-Sigma
    dist <- Distribution
    target <- Target

    Hinweis <- "Runden Sie die Ergebnisse, falls nötig, auf 4 Nachkommastellen und gehen Sie vom Modell mit Zurücklegen aus."
    Text <- paste(Text1, n, Text2, paste(strsplit(as.character(prop),"\\.")[[1]],collapse=","), Text3)
    Text <-  c(Text,Hinweis)

    borders <- CalculateCI(n=n, alpha=alpha, prop=prop,  Universe=dist, Sigma=sigma, Target=target)
    b <- round(borders,4)
    d <- sample(seq(0.01,round(prop-borders[1],2)-0.02, 0.01),1)

    nstar <- ceiling(prop*(1-prop)*(2*round(qnorm(1-alpha/2),4))^2/d^2)

    UG <- "Bestimmen Sie die Untergenze"
    OG <- "Bestimmen Sie die Obergenze"
    pre <- c(UG,OG)


    Q <- paste(pre, " des ", (1-alpha)*100, "%-Konfidenzintervalls ", Info, ".", sep="")
    Qsamp <- paste("Ermitteln Sie den notwendigen Stichprobenumfang [tex]n[/tex] für ein ", (1-alpha)*100, "%-Konfidenzintervall der Länge [tex]d \\le [/tex] ", paste(strsplit(as.character(d),"\\.")[[1]],collapse=","), ".", sep="")
    Question <- c(Q,Qsamp)

    Answer <- rbind(cbind(b-0.0005,b,b+0.0005), c(nstar-0.01,nstar,nstar+0.01))
    dimnames(Answer) <- NULL
    Answer[Answer<0] <- 0

    return(Question(Type = "NumericGaps", Text = Text, Tab=NULL, Titel = paste(Titel, sprintf("%05d", iter), sep = ""),
                    Question = Question, Answer = Answer, Points = Points))

}

## QP <- sapply(1:100, function(i) NumGapsQ_CIprop(
##                     Text1 = "Die Stadt Trier möchte den Anteil der Haushalte, die als armutsgefährdet gelten, schätzen. Dazu möchte man eine Stichprobe vom Umfang [tex]n= ",
##                     Text2 = " [/tex] ziehen. Aus anderen Studien ist bekannt, dass mit einem Anteil armutsgefährdeter Haushalte von [tex]\\theta= ",
##                     Text3 = " [/tex] zu rechnen ist.",
##                     Info = "für den Anteil [tex]\\theta[/tex] der armutsgefährdeten Haushalte",
##                     Points = c(0.1, 0.1, 0.3),
##                     iter = i,
##                     Titel = "IS.K4.NumGapsQ.002.",
##                     prop = sample(seq(0.2,0.8,0.05),1),
##                     n = sample(seq(100,250,15),1)
##
##             )
## )

NumGapsQ_ME_KI_PS_GGNV <-function(Text=NULL, Question=NULL, Points, tol, Titel, iter){

#Daten der Grundgesamtheit
    mu <- sample(seq(3,5,0.01),1)
    sigma <- sample(seq(0.5,1.5,0.001),1)
#Stichprobendaten
    n <- sample(seq(5,10,1),1)
    Zeile1 <- 1:n
    Preis <- round(rnorm(n, mean=mu, sd=sigma),digits=2)
#Frage 2
    alpha <- c(0.1,0.05,0.01)
    alphaeins <- sample(alpha,1)

    if(alphaeins == 0.1) zval <- 1.645
    if(alphaeins == 0.05) zval <- 1.96
    if(alphaeins == 0.01) zval <- 2.575
#Frage4
    alphazwei <- sample(alpha,1)
    SPV <- var(Preis)
    df <- n-1

    Text1 <- "Auf dem Wochenmarkt in einer Großstadt werden an den Verkaufsständen Erdbeeren zu je 1kg verkauft. Der Verkaufspreis pro kg Erdbeeren hat eine Standardabweichung von "
    Text2 <- "Euro."
    Text3 <- "Es kann dabei von einer Normalverteilung des Verkaufspreises je kg Erdbeeren ausgegangen werden. Eine Stichprobe von "
    Text4 <- " Verkaufsständen an einem Tag ergab folgendes Ergebnis:"


    Tab <- matrix(ncol=2,nrow=n+1)
    Tab[,1]   <- "Verkaufsstand"
    Tab[,2]   <- "Verkaufspreis pro kg"
    Tab[-1,1] <- Zeile1
    Tab[-1,2] <- Preis
    Tab

    Q1 <- "Bestimmen Sie anhand der Stichprobenwerte einen geeigneten Punktschätzwert für den durchschnittlichen Verkaufspreis pro kg Erdbeeren."
    Q2 <- paste("Bestimmen Sie anhand der Stichprobenwerte die untere Grenze des ",(1-alphaeins)*100,"%-Konfidenzintervall für den durchschnittlichen Verkaufspreis pro kg Erdbeeren.")
    Q3 <- paste("Bestimmen Sie anhand der Stichprobenwerte die obere Grenze des ",(1-alphaeins)*100,"%-Konfidenzintervall für den durchschnittlichen Verkaufspreis pro kg Erdbeeren.")
    Q4 <- paste("Bestimmen Sie anhand der Stichprobenwerte die untere Grenze des ",(1-alphazwei)*100,"%-Konfidenzintervall für den durchschnittlichen Verkaufspreis pro kg Erdbeeren unter der Annahme, dass die Standardabweichung der Grundgesamtheit unbekannt ist.")
    Q5 <- paste("Bestimmen Sie anhand der Stichprobenwerte die obere Grenze des ",(1-alphazwei)*100,"%-Konfidenzintervall für den durchschnittlichen Verkaufspreis pro kg Erdbeeren unter der Annahme, dass die Standardabweichung der Grundgesamtheit unbekannt ist.")
    Hinweis <- "Runden Sie die Ergebnisse, falls nötig, auf vier Nachkommastellen."
    Question <- c(Q1,Q2,Q3,Q4,Q5)

    Text <- c(paste(Text1,sigma,Text2,Text3,n,Text4),Hinweis)

    A1 <- mean(Preis)
    A2 <- mean(Preis) - (zval * (sigma/sqrt(n)))
    A3 <- mean(Preis) + (zval * (sigma/sqrt(n)))
    A4 <- mean(Preis) - (round(qt((1-(alphazwei/2)),df=df),3) * sqrt(SPV/n))
    A5 <- mean(Preis) + (round(qt((1-(alphazwei/2)),df=df),3) * sqrt(SPV/n))
    Answer <- matrix(c(A1,A2,A3,A4,A5),ncol=3, nrow=5)
    Answer[,1] <- Answer[,1] -tol
    Answer[,3] <- Answer[,3] +tol

    return(Question(Type = "NumericGaps", Text = Text, Tab=Tab, Titel = paste(Titel, sprintf("%05d", iter), sep = ""),
                    Question = Question, Answer = Answer, Points = Points))
}

## QP <- sapply(1:100, function(i) NumGapsQ_ME_KI_PS_GGNV(
##                     tol = 0.02,
##                     Titel = "IS.K4.NumGapsQ.001.",
##                     iter = i,
##                     Points = c(0.1, 0.1, 0.1, 0.1, 0.1)
##             )
## )


#######################################################################################################################################################
#
# 		SINGLE CHOICE QUESTIONS
#
#######################################################################################################################################################


### 1) SingleChoice question: Simple single choice question


SCQ_4SimpleAnswers <- function(Text,Question,Points,Titel,iter,CorrectAnswer,WrongAnswers){

  Answer <- c(CorrectAnswer,WrongAnswers) # correct answer must be the first element of all possible answers

  return(
    Question(Type="SingleChoice", Text=Text, Tab=NULL, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=Points)
  )
}

### Example for function call:

#SCQ_4SimpleAnswers(

#    Text = NULL,   # Description of task or issue of the question
#    Titel = "Question_SC4Answers_",     # Number or content of the question
#    Quest = "Which of the following numbers is called the Euler number?",   # Formulation of a concrete question (Questions and/or Text can contain LaTeX elements).
#    Points = c(2,0,0,0),     # The achievable number of points must be specified as vectors, where the first element need to be the points for the correct answer.
#    iter = x,      # Number of different questions that should be generated
#    CorrectAnswer = 2.7183,     # Specify excatly one correct answer
#    WrongAnswers = c(1.141,1.732,3.142)     # Specify wrong answers as many as you want, but adjust the points in accordance with answers
#)

# Further comments:
# -
# -





### 2) SingleChoice question: Sample random questions with according answers


SCQ_RandomQuestions <- function(Text,Question,Points,Titel,iter,Answers1,Answers2,Answers3,Answers4){

  variation.question <- sample(1:4,1)
  Question <- paste("Which of the following numbers has",variation.question,"digits?")
  randomAnswer <- c(sample(Answers1,1),sample(Answers2,1),sample(Answers3,1),sample(Answers4,1))
  if(variation.question==1){
        CorrectAnswer <- randomAnswer[1]
        WrongAnswers <- c(randomAnswer[2],randomAnswer[3],randomAnswer[4])
  }
  if(variation.question==2){
        CorrectAnswer <- randomAnswer[2]
        WrongAnswers <- c(randomAnswer[1],randomAnswer[3],randomAnswer[4])
  }
  if(variation.question==3){
        CorrectAnswer <- randomAnswer[3]
        WrongAnswers <- c(randomAnswer[1],randomAnswer[2],randomAnswer[4])
  }
  if(variation.question==4){
        CorrectAnswer <- randomAnswer[4]
        WrongAnswers <- c(randomAnswer[1],randomAnswer[2],randomAnswer[3])
  }
  Answer <- c(CorrectAnswer,WrongAnswers) # correct answer must be the first element of all possible answers

  return(
    Question(Type="SingleChoice", Text=Text, Tab=NULL, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=Points)
  )
}

### Example for function call:

#SCQ_RandomQuestions(

#    Text = NULL,   # Description of task or issue of the question
#    Titel = "Question_SC_RandomQuestions_",     # Number or content of the question
#    Quest = Question,   # Formulation of a concrete question (Questions and/or Text can contain LaTeX elements). Question is defined within the function.
#    Points = c(2,0,0,0),     # The achievable number of points must be specified as vectors, where the first element need to be the points for the correct answer.
#    iter = x,      # Number of different questions that should be generated
#    Answers1 = c(1,2,3,4),   # Vector for the first group of answers
#    Answers2 = c(11,22,33,44),   #   Vector for the second group of answers
#    Answers3 = c(111,222,333,444),   #   Vector for the third group of answers
#    Answers4 = c(1111,2222,3333,4444)   #   Vector for the fourth group of answers, etc.
#)

# Further comments:
# -
# -






### 3) SingleChoice question: Sample random answers and adapt question


SCQ_RandomAnswer <- function(Text,Question,Points,Titel,iter,Answers1,Answers2,Answers3,Answers4){

  randomAnswer <- sample(c(Answers1,Answers2,Answers3,Answers4),1)
  Question <- paste("How many digits does the number",randomAnswer,"have?")
  if(is.element(randomAnswer,Answers1)){
        CorrectAnswer <- "One digit"
        WrongAnswers <- c("Two digits","Three digits","Four digits")
  }
 if(is.element(randomAnswer,Answers2)){
        CorrectAnswer <- "Two digits"
        WrongAnswers <- c("One digit","Three digits","Four digits")
  }
 if(is.element(randomAnswer,Answers3)){
        CorrectAnswer <- "Three digits"
        WrongAnswers <- c("One digit","Two digits","Four digits")
  }
 if(is.element(randomAnswer,Answers4)){
        CorrectAnswer <- "Four digits"
        WrongAnswers <- c("One digit","Two digits","Three digits")
  }
  Answer <- c(CorrectAnswer,WrongAnswers) # correct answer must be the first element of all possible answers

  return(
    Question(Type="SingleChoice", Text=Text, Tab=NULL, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=Points)
  )
}

### Example for function call:

#SCQ_RandomAnswer(

#    Text = NULL,   # Description of task or issue of the question
#    Titel = "Question_SC4randomAnswer_",     # Number or content of the question
#    Quest = Question,   # Formulation of a concrete question (Questions and/or Text can contain LaTeX elements). Question is defined within the function.
#    Points = c(2,0,0,0),     # The achievable number of points must be specified as vectors, where the first element need to be the points for the correct answer.
#    iter = x,      # Number of different questions that should be generated
#    Answers1 = c(1,2,3,4),   # Vector for the first group of answers
#    Answers2 = c(11,22,33,44),   #   Vector for the second group of answers
#    Answers3 = c(111,222,333,444),   #   Vector for the third group of answers
#    Answers4 = c(1111,2222,3333,4444)   #   Vector for the fourth group of answers, etc.
#)

# Further comments:
# -
# -



### 4) SingleChoice question: Answers depending on an arithmetical task:


SCQ_ArithmeticMean.Task <- function(Text,Question,Points,Titel,iter,x,CorrectAnswer,WrongAnswers){

  CorrectAnswer <- round(mean(x),2)
  WrongAnswers <- c(CorrectAnswer - sample(seq(0.5,3,0.5),1), CorrectAnswer+sample(seq(0.5,3,0.5),1), CorrectAnswer * (1 - sample(seq(0.05,0.15,0.05),1)),CorrectAnswer * (1 + sample(seq(0.05,0.15,0.05),1)))
  Answer <- c(CorrectAnswer,WrongAnswers) # correct answer must be the first element of the answer vector

  Tab <- matrix(NA,ncol=length(x)+1,nrow=1)
  Tab[1,] <- c("Values for x",x)

  return(
    Question(Type="SingleChoice", Text=Text, Tab=Tab, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=Points)
  )
}

### Example for function call:

#SCQ_ArithmeticMean.Task(
#    Text = "The following table provides information on the values of a metric variable X:",   # Description of task or issue of the question
#    Titel = "Question_Mean_",     # Number or content of the question
#    Quest = "Calculate the arithmatic mean for the given values of X.",   # Formulation of a concrete question (Questions and/or Text can contain LaTeX elements).
#    Points = c(2,0,0,0,0),     # The achievable number of points must be specified as vectors, where the first element need to be the points for the correct answer. Length is depending on total number of correct answer + wrong answers
#    iter = x,      # Number of different questions that should be generated
#    x = sample(seq(20,30,1),10),     # vector of values for x variable
#    CorrectAnswer = CorrectAnswer,     # Specify excatly one correct answer -> here within the function
#    WrongAnswers = WrongAnswers     # Specify wrong answers as many as you want, but adjust the points according to the number of answers
#)

# Further comments:
# -
# -


SCQ_Lorenz <- function (Text, Question, Points, Titel, sampProbsExt, iter, Infos, type="Lorenzkurve") {
  sampProbs <- sampProbsExt[,sample(1:8,4)]
  S <- sample(1:4,1)
  F <- seq(1,4,1)[-S]
  Correct <- sampProbs[,S]
  Wrong   <- sampProbs[,-S]
  n       <- length(Correct)

  SPsort  <- apply(sampProbs,2,sort)
  SPcum   <- apply(SPsort,2,cumsum)

  SPdecr  <- apply(sampProbs,2,function(x) sort(x,decreasing=T))
  SPalph  <- apply(SPdecr,2,function(x) cumsum(x)/sum(x))

  lor4MQ <- function(x, num, type) {
    if(type=="Lorenzkurve"){
      plot(0:n/n, c(0,x), main = paste(type, num), xlab="Anteil Merkmalsträger", ylab="Anteil Merkmalsbetrag",type="l",xlim=c(0,1),ylim=c(0,1))
      points(0:n/n, c(0,x), pch=19)
      lines(c(0,1),c(0,1))
    }
    else {plot(0:n, c(0,x), main = paste(type, num), xlab="Anzahl Merkmalsträger", ylab="Anteil Merkmalsbetrag",type="l",xlim=c(0,n),ylim=c(0,1))
      points(0:n, c(0,x), pch=19)
      lines(c(0,n),c(0,1))
    }
  }

  Image <- tempfile(pattern = "file", tmpdir = tempdir())
  jpeg(filename= Image, quality = 100, width = 672, height = 671)

  if(type=="Lorenzkurve"){
    par(mfrow = c(2, 2))
    lor4MQ(SPcum[,1], 1, type)
    lor4MQ(SPcum[,2], 2, type)
    lor4MQ(SPcum[,3], 3, type)
    lor4MQ(SPcum[,4], 4, type)
  }

  if(type=="Konzentrationskurve"){
    par(mfrow = c(2, 2))
    lor4MQ(SPalph[,1], 1, type)
    lor4MQ(SPalph[,2], 2, type)
    lor4MQ(SPalph[,3], 3, type)
    lor4MQ(SPalph[,4], 4, type)
  }

  dev.off()


  tab <- matrix(NA,nrow=1,ncol=n+1)
  tab[1,1]   <- Infos

  if(type=="Lorenzkurve") {
    tab[1,-1]  <- sample(Correct)
  }

  if(type=="Konzentrationskurve") {
    tab[1,-1]  <- sample(Correct)*25000
  }

  Answer <- c(S,F) # correct answer must be the first element of all possible answers

  return(Question(Type = "SingleChoice", Text = Text, Tab = tab,
          Titel = paste(Titel, sprintf("%05d", iter), sep = ""),
          Question = Question, Answer = Answer, Points = Points, Image = GetBase64(Image), ImageCoord = NULL))
}

## QP <- sapply(1:100, function(i) SCQ_Lorenz(
##                     Text = "Folgende Information sei über den Marktanteil der 5 Bäckereien in Filsch bekannt",
##                     Question = "Welche Lorenzkurve entspricht den Marktanteilen in der Tabelle?",
##                     Points = 0.4,
##                     Titel = "DS.K3.SCQ.002.",
##                     iter = i,
##                     Infos = "Marktanteil der Bäckereien",
##                     sampProbsExt = cbind(c(0.1,0.1,0.1,0.1,0.6),c(0.15,0.15,0.2,0.2,0.3),c(0.1,0.25,0.15,0.15,0.35),c(0.1,0.1,0.1,0.25,0.45),
##                             c(0.025,0.05,0.075,0.1,0.75),c(0.15,0.2,0.2,0.2,0.25),c(rep(0.05,4),0.8),c(rep(0.15,4),0.4))
##             )
## )

SCQ_Img <- function(Text,Question,Points,Titel,mu,sigma,N,iter){
  X <- matrix(NA,ncol=4,nrow=N)
  X <- sapply(1:4, function(i) X[,i] <- rnorm(N,mu[i],sigma[i]))
  mu.emp  <- round(apply(X,2,mean),2)
  sig.emp <- round(apply(X,2,sd),2)

  hist4MQ <- function(y,num){
    hist(y,breaks=20,col="blue",main=paste("Histogramm",num),xlab="",ylab="absolute Häufigkeiten")
  }

#  fancyplot4MQ<-function(x,type,num){
#		switch(type,
#				fanHist =  hist(x, breaks=20, main = paste("Bild",num),col="blue",xlab="",ylab="absolute Häufigkeiten"),
#				fanBox  =  boxplot(x,main=paste("Bild",num)),
#		)
#	}


  Image <- tempfile(pattern = "file", tmpdir = tempdir())
  jpeg(filename= Image, quality = 100, width = 672, height = 671)

  par(mfrow=c(2,2))
  hist4MQ(X[,1],1)
  hist4MQ(X[,2],2)
  hist4MQ(X[,3],3)
  hist4MQ(X[,4],4)

  dev.off()			# Beendet die Speicherung als .jpeg

  correct <- sample(1:4,1)
  wrong   <- seq(1,4,1)[-correct]
  tab <- matrix(NA,nrow=2,ncol=2)
  tab[1,]  <- c("Mittelwert","Standardabweichung")
  tab[2,]  <- cbind(mu.emp,sig.emp)[correct,]

  Answer <- c(correct,wrong) # correct answer must be the first element of all possible answers

  return(
      Question(Type="SingleChoice", Text=Text, Tab=tab, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=Points, Image=GetBase64(Image),ImageCoord=NULL)
  )
}

## QuestionPool <- sapply(1:100, function(i) SCQ_Img(
##                     Text     = "Gegeben ist die folgende Verteilung:",
##                     Question = "Zu welchem Histogramm gehört diese Verteilung",
##                     Points   = 0.4,
##                     Titel    = "DS.K3.SCQ.001.",
##                     mu       = rep(sample(c(1.5,2,3,3),1),4),
##                     sigma    = c(2,0.5,1.5,1),
##                     N        = 1000,
##                     iter     = i
##             ))

SCQ_DIST <-
    function (Text, Question, Points, Titel, iter, XX)
{
  options(scipen=10)
  Z <- apply(XX,1,cumsum)
  s <- sample(1:8,4)
  x <- XX[s,]
  z <- t(Z[,s])
  S <- sample(1:4,1)
  F <- seq(1,4,1)[-S]
  n <- length(x[1,])
  sdisp <- sample(c("density","cdf"),4,T)
  dist4MQ <- function(x,z, num, type) {
    #boxplot(y, main = paste("Boxplot", num))
    switch(type,
        density = discplot.density(x,z, main=paste("Grafik",num)),
        cdf = discplot.cdf(x,z, main=paste("Grafik",num))
    )
  }
  Image <- tempfile(pattern = "file", tmpdir = tempdir())
  jpeg(filename= Image, quality = 100, width = 672, height = 671)
  par(mfrow=c(2,2))
  dist4MQ(n-1, x[1,], 1, sdisp[1])
  dist4MQ(n-1, x[2,], 2, sdisp[2])
  dist4MQ(n-1, x[3,], 3, sdisp[3])
  dist4MQ(n-1, x[4,], 4, sdisp[4])
  dev.off()

  Answer <- c(S,F)

  tab <- matrix(nrow = n+1, ncol = 3)
  tab[1, ] <- c("[tex]x_i[/tex]", "[tex]f(x_i)[/tex]", "[tex]F(x_i)[/tex]")
  tab[-1, 1] <- 0:(n-1)
  tab[-1, 2] <- x[S,]
  tab[-1, 3] <- cumsum(x[S,])
  return(Question(Type = "SingleChoice", Text = Text, Tab = tab, Titel = paste(Titel, sprintf("%05d", iter), sep = ""),
          Question = Question, Answer = Answer, Points = Points, Image = GetBase64(Image), ImageCoord = NULL))

}
## QP <- sapply(1:100, function(i) SCQ_DIST(
##                     Text = "Gegeben Sei die folgende Verteilung",
##                     Question = "Welcher Grafik entspricht die in der Tabelle dargestellte Verteilung?",
##                     Points = 0.4,
##                     Titel = "IS.K2.SCQ.001",
##                     XX = XX,
##                     iter = i
##             )
## )

discplot.density <- function(x,z,...) {
  plot(z,type="h",xaxt="n",xlab="x",ylim=c(0,1), ylab="f(x)",...)
  axis(1, at=1:(x+1), labels=0:x)
  points(z)
}

discplot.cdf <- function(x,z,...) {
  z.cum <- cumsum(z)
  xvec <- 0:x
  xv1 <- xvec+1
  z.cum0 <- c(0,z.cum)
  xvecm <- c(min(xvec)-1,xvec)
  xv1m <- c(0,xv1)
  plot(xvec,z.cum,ylab="F(x)",xlab="x",xaxt="n",ylim=c(0,1),pch=19,...)
  segments(xvecm,z.cum0,xv1m,z.cum0)
  axis(1, at=0:x, labels=0:x)
  points(xvec,z.cum0[-length(z.cum0)])

}

#######################################################################################################################################################
#
# 		MULTIPLE CHOICE QUESTIONS
#
#######################################################################################################################################################


### 1) MultipleChoice question:


MCQ_RandomAnswers <- function(Text,Question,Points,Titel,iter,NoTotalAnswers,CorrectStatements,WrongStatements){

  NoCorrectAnswers <- sample(c(1:(NoTotalAnswers-1)),1)
  NoWrongAnswers <- NoTotalAnswers - NoCorrectAnswers

  SampleCorrectStatements <- sample(CorrectStatements,NoCorrectAnswers)
  SampleWrongStatements <- sample(WrongStatements,NoWrongAnswers)

  Answer <- c(SampleCorrectStatements,SampleWrongStatements) # correct answer must be the first element of all possible answers

  return(
      Question(Type="MultipleChoice", Text=Text, Tab=NULL, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=c(rep(Points,NoCorrectAnswers),rep(-Points,NoWrongAnswers)))
  )
}

MCQ_RandomQuestionsRandomAnswers <- function(Text,Questions,Points,Titel,iter,NoTotalAnswers,CorrectStatements,WrongStatements){

  NoCorrectAnswers <- sample(c(1:(NoTotalAnswers-1)),1)
  NoWrongAnswers <- NoTotalAnswers - NoCorrectAnswers

  Qsam <- sample(1:length(Questions),1)

  SampleCorrectStatements <- sample(CorrectStatements[[Qsam]],NoCorrectAnswers)
  SampleWrongStatements   <- sample(WrongStatements[[Qsam]],NoWrongAnswers)

  Answer <- c(SampleCorrectStatements,SampleWrongStatements) # correct answer must be the first element of all possible answers

  return(
      Question(Type="MultipleChoice", Text=Text, Tab=NULL, Titel=paste(Titel,sprintf("%05d",iter),sep=""),
          Question=Questions[Qsam],Answer=Answer,Points=c(rep(Points,NoCorrectAnswers),rep(-Points,NoWrongAnswers)))
  )
}

MCQ_RandomQuestionsRandomAnswers2posibilities <- function(Text,Questions,Points,Titel,iter,NoTotalAnswers,Correct1,Correct2) {
  if(length(Questions)!=2) stop("Only two Questions allowed in function MCQ_RandomQuestionsRandomAnswers2posibilities")
  Qsam <- sample(1:2,1)
  if(Qsam==1) {
    return(MCQ_RandomQuestionsRandomAnswers(Text,Questions[Qsam],Points,Titel,iter,NoTotalAnswers,Correct1,Correct2))
  } else {
    return(MCQ_RandomQuestionsRandomAnswers(Text,Questions[Qsam],Points,Titel,iter,NoTotalAnswers,Correct2,Correct1))
  }
}

### Example for function call:

#MCQ_RandomAnswers(

#    Text = NULL,   # Description of task or issue of the question
#    Titel = "Question_MC_RandomAnswers_",     # Number or content of the question
#    Quest = "Which of the following statements do you agree with?",   # Formulation of a concrete question (Questions and/or Text can contain LaTeX elements). Question is defined within the function.
#    Points = function(A,CA)ifelse(is.element(A,CA),Points <- 1,Points <- -1),     # The achievable number of points must be specified as vectors, where points are depending on randomly drawn answers
#    iter = x,      # Number of different questions that should be generated
#    NoTotalAnswers = 4,  # Number of elements/statements in the multiple choice question
#    CorrectStatements = c("C1","C2","C3","C4","C5","C6","C7"),   # Vector of correct statements; also collection of statements as .txt file possible
#    WrongStatements = c("W1","W2","W3","W4","W5","W6","W7")   #   Vector of wrong statements
#)


# Further comments:
# -
# -





### 2) MultipleChoice question:


MCQ_RandomQuestions <- function(Text,Question,Points,Titel,iter,NoTotalAnswers,variation.question.1,variation.question.2){

  Statements1 <- c(sample(1:(variation.question.1 - 1),10))
  Statements2 <- c(sample((variation.question.1 + 1) : (variation.question.1 *2),10))
  Question <- paste("Which of the following numbers are",variation.question.2,"than",variation.question.1,"?")
  if(variation.question.2=="lower"){
        CorrectAnswer <- Statements1
        WrongAnswer <- Statements2
  }
  if(variation.question.2=="greater"){
        CorrectAnswer <- Statements2
        WrongAnswer <- Statements1
  }
  NoAnswers1 <- sample(c(1:(NoTotalAnswers-1)),1)
  NoAnswers2 <- NoTotalAnswers - NoAnswers1
  Answer <- c(sample(CorrectAnswer,NoAnswers1),sample(WrongAnswer,NoAnswers2))

  return(
    Question(Type="MultipleChoice", Text=Text, Tab=NULL, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=Points(Answer,CorrectAnswer))
  )
}

### Example for function call:

#MCQ_RandomQuestions(

#    Text = NULL,   # Description of task or issue of the question
#    Titel = "Question_MC_RandomQuestions_",     # Number or content of the question
#    Quest = Question,   # Formulation of a concrete question (Questions and/or Text can contain LaTeX elements). Question is defined within the function.
#    Points = function(A,CA)ifelse(is.element(A,CA),Points <- 1,Points <- -1),     # The achievable number of points must be specified as vectors, where points are depending on randomly drawn answers
#    iter = x,      # Number of different questions that should be generated
#    NoTotalAnswers = 4,  # Total number of elements/statements in the multiple choice question
#    variation.question.1 = sample(seq(100,1000,100),1),    # first variation condition of question
#    variation.question.2 = sample(c("lower","greater"),1)   # second variation condition of question
#)


# Further comments:
# -
# -



#######################################################################################################################################################
#
# 		MATCHING QUESTIONS
#
#######################################################################################################################################################



### 1) Matching question:



MQ_SimpleMatching <- function(Text,Question,Points,Titel,iter,AttributableGroup,MatchingGroup){

  Answer <- matrix(c(AttributableGroup,MatchingGroup),nrow=length(MatchingGroup),ncol=2)
  Answer1 <- Answer[,1]
  Answer2 <- Answer[,2]

  return(
    Question(Type="Matching", Text=Text, Tab=NULL, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=Points(Answer))
  )
}

### Example for function call:

#MQ_SimpleMatching(

#    Text = NULL,   # Description of task or issue of the question; NULL if no text is needed
#    Titel = "Question_MQ_Simple_",     # Number or content of the question
#    Quest = "Please allocate the given lower case letters to their respective capital letters.",   # Formulation of a concrete question (Questions and/or Text can contain LaTeX elements).
#    Points = function(A)rep(1,dim(A)[1]),     # The achievable number of points is depending on the number of possible matchings -> for each matching there must be allocated the same number of points
#    iter = x,      # Number of different questions that should be generated
#    AttributableGroup = c("A","B","C","D"),  # Group of elements/categories, for which a specific MatchingGroup item exist
#    MatchingGroup = c("a","b","c","d")      # Group of elements, which should be allocated to AttributableGroup
#)


# Further comments:
# -
# -





### 2) Matching question:

MQ_MatchRandomElements <- function(Text=NULL,Question,Points,Titel,iter,AttributableGroup,MatchingGroups){
  if(length(AttributableGroup)!=length(MatchingGroups)) stop ("Length of 'AttributableGroup' is not equal to the length of 'MatchingGroups'")
  MatchingGroup  <- sapply(MatchingGroups,function(x)sample(x,1))
  Answer         <- matrix(c(AttributableGroup,MatchingGroup),nrow=length(MatchingGroup),ncol=2)
  return(
    Question(Type="Matching", Text=Text, Tab=NULL, Titel=paste(Titel,sprintf("%05d",iter),sep=""),
             Question=Question,Answer=Answer,Points=rep(Points,length(AttributableGroup)))
  )
}

### Example for function call:

#MQ_MatchRandomElements(

#    Text = NULL,   # Description of task or issue of the question; NULL if no text is needed
#    Titel = "Question_MQ_RandomElements_",     # Number or content of the question
#    Quest = "Please allocate the given characteristics to their respective scale level.",   # Formulation of a concrete question (Questions and/or Text can contain LaTeX elements).
#    Points = function(A)rep(1,dim(A)[1]),     # The achievable number of points is depending on the number of possible matchings -> for each matching there must be allocated the same number of points
#    iter = x,      # Number of different questions that should be generated
#    AttributableGroup = c("Nominal scale","Ordinal scale","Interval scale","Ratio measurement"),  # Group of elements/categories, for which a specific MatchingGroup item exist
#    MatchingGroups = list(c("Gender","Colors","Party affiliation"),
#                            c("School grades","Clothing sizes","Boxing weight classes","Service grade in the army"),
#                            c("Temperature in C","Temperature in F","Year dates","Calendar data"),
#                            c("GDP","Net income","Height","Weight","Speed","Temperature in K","Household size") )
#)

# Further comments:
# - different groups do not necessarily need to be of the same length
# -




### 3) Matching question: Include an image


MQ_ImageMatching <- function(Text=NULL,Question,Points,Titel,iter,AttributableGroup,MatchingGroup){

  Image <- paste(tempfile(pattern = "file", tmpdir = tempdir()),"jpg",sep=".")			# path for temporary image file
  jpeg(filename=Image, quality=100 , width=700, height=700)				# parameters of temporary image file

  random <- sample(1:4)
  norm <- matrix(NA,ncol=4,nrow=2,byrow=TRUE)
  norm[,1] <- c(0,1)
  norm[,2] <- c(0,sample(3:5,1))
  norm[,3] <- c(sample(4:8,1),sample(1:2,1))
  norm[,4] <- c(sample(4:8,1),sample(3:5,1))

  x <- matrix(NA,ncol=4,nrow=1000,byrow=TRUE)
  x[,1] <- seq(norm[1,1]-8,norm[1,1]+8,length=1000)
  x[,2] <- seq(norm[1,2]-8,norm[1,2]+8,length=1000)
  x[,3] <- seq(norm[1,3]-8,norm[1,3]+8,length=1000)
  x[,4] <- seq(norm[1,4]-8,norm[1,4]+8,length=1000)
  plot(x[,1],dnorm(x[,1],norm[1,1],norm[2,1]),col=random[1],lwd=2,type="l",xlim=c(-10,20),ylim=c(0,0.5),ylab="density functions",xlab="x",main="Different normal distributions")
  for (i in 2:4){
  lines(x[,i], dnorm(x[,i],norm[1,i],norm[2,i]), lwd=2, col=random[i])
  }
  # answer depending on random -> important for colored functions and parameters

  dev.off()     # close temporary image file

  #AttributableGroup <- c()
  for(i in 1:length(random)){
  if(random[i]==1){AttributableGroup[i] <- paste("Black density function")}
  if(random[i]==2){AttributableGroup[i] <- paste("Red density function")}
  if(random[i]==3){AttributableGroup[i] <- paste("Green density function")}
  if(random[i]==4){AttributableGroup[i] <- paste("Blue density function")}
  }
  #MatchingGroup <- c()
  for(i in 1:length(random)){
  if(random[i]==1){MatchingGroup[i] <- paste("Parameters: Mu=",norm[1,i],"and Sigma=",norm[2,i])}
  if(random[i]==2){MatchingGroup[i] <- paste("Parameters: Mu=",norm[1,i],"and Sigma=",norm[2,i])}
  if(random[i]==3){MatchingGroup[i] <- paste("Parameters: Mu=",norm[1,i],"and Sigma=",norm[2,i])}
  if(random[i]==4){MatchingGroup[i] <- paste("Parameters: Mu=",norm[1,i],"and Sigma=",norm[2,i])}
  }

  Answer <- matrix(c(AttributableGroup,MatchingGroup),nrow=length(MatchingGroup),ncol=2)


  return(
    Question(Type="Matching", Text=Text, Tab=NULL, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=rep(Points,length(AttributableGroup)),Image=GetBase64(Image),ImageCoord=NULL)
  )
}

### Example for function call:

#MQ_ImageMatching(

#    Text = NULL,   # Description of task or issue of the question; NULL if no text is needed
#    Titel = "Question_MQ_Image_",     # Number or content of the question
#    Quest = "Please allocate the given parameters of normally distributed function to their respectivly coloured density functions.",   # Formulation of a concrete question (Questions and/or Text can contain LaTeX elements). Question is defined within the function.
#    Points = function(A)rep(1,dim(A)[1]),     # The achievable number of points is depending on the number of possible matchings -> for each matching there must be allocated the same number of points
#    iter = x,      # Number of different questions that should be generated
#    AttributableGroup = c() ,   # Attributable group need to be defined within the function
#    MatchingGroup = c()      # Matching group need to be defined within the function
#)

# Further comments:
# -
# -

### 4) Matching question for distributions
MQ_Dist_nc <- function(Text,Question,Points,Titel,iter,extended){
  x1 <- getprobs(500,4,5)
  x2 <- getprobs(500,4,5)
  while(sum(abs(x1 - x2)) < 0.0001){
    x2 <- getprobs(500,4,5)
  }
  x3 <- getprobs(500,4,5)
  while((sum(abs(x1 - x2)) < 0.0001) | (sum(abs(x2 - x3)) < 0.0001)){
    x3 <- getprobs(500,4,5)
  }
  x4 <- getprobs(500,4,5)
  while((sum(abs(x1 - x4)) < 0.0001) | (sum(abs(x2 - x4)) < 0.0001) | (sum(abs(x3 - x4)) < 0.0001) ){
    x4 <- getprobs(500,4,5)
  }

  barplot4MQ<-function(x,type,num){
    switch(type,
        kreis =  pie(x, main = paste("Bild",num),col=c(2,3,4,7)),
        horizT  =  barplot(x,main=paste("Bild",num),col=c(2,3,4,7),horiz=T,xlab="Absolute Häufigkeiten",ylab="Fachrichtungen"),
        horizF =  barplot(x,main=paste("Bild",num),col=c(2,3,4,7),horiz=F,ylab="Absolute Häufigkeiten",xlab="Fachrichtungen")
    )
  }


  # Zusammenfassung der Daten in einer Matrix mit Bezeichnungen
  x <- matrix(c(x1,x2,x3,x4),nrow=4,byrow=T, dimnames=list(c("","","",""),c("Statistik","Soziologie","VWL","BWL")))
  sample.col <- sample(1:4,4,replace=F)
  if (extended == TRUE) {sample.var <- sample(c("horizT","horizF","kreis"),4,T)} else {sample.var <- rep(sample(c("horizT","horizF","kreis"),1),4)}

  Image <- tempfile(pattern = "file", tmpdir = tempdir())
  jpeg(filename= Image, quality = 100, width = 672, height = 671)
  # Generierung einer "Zeichnungs-Matrix" & Füllung dieser mit zufälligen Diagrammen der jeweiligen Datensätze
  par(mfrow=c(2,2))
  barplot4MQ(x[sample.col[1],],sample.var[1],1)
  barplot4MQ(x[sample.col[2],],sample.var[2],2)
  barplot4MQ(x[sample.col[3],],sample.var[3],3)
  barplot4MQ(x[sample.col[4],],sample.var[4],4)
  dev.off()

  fix.group <- c("Bild 1","Bild 2","Bild 3","Bild 4")
  # Benennung der vier Datenreihen/-felder für die Zuordnung und Mitgabe der jeweiligen Verteilungswerte
  matching1 <- c(paste("Fach 1 =",x[1,1],", Fach 2 =",x[1,2],", Fach 3 =",x[1,3],", Fach 4 =",x[1,4],sep=" "))
  matching2 <- c(paste("Fach 1 =",x[2,1],", Fach 2 =",x[2,2],", Fach 3 =",x[2,3],", Fach 4 =",x[2,4],sep=" "))
  matching3 <- c(paste("Fach 1 =",x[3,1],", Fach 2 =",x[3,2],", Fach 3 =",x[3,3],", Fach 4 =",x[3,4],sep=" "))
  matching4 <- c(paste("Fach 1 =",x[4,1],", Fach 2 =",x[4,2],", Fach 3 =",x[4,3],", Fach 4 =",x[4,4],sep=" "))

  # Erstellen eines Vektors, der die Elemente der 4 Datenreihen enthält
  matching.group <- c(matching1,matching2,matching3,matching4)

  # Mitgabe der Übereinstimmungen in einer Matrix
  Answer <- matrix(c(fix.group,c(matching.group[sample.col[1]],matching.group[sample.col[2]],matching.group[sample.col[3]],matching.group[sample.col[4]])),nrow=4, ncol=2 )


  return(
      Question(Type="Matching", Text=Text, Tab=NULL, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=rep(Points,4), Image=GetBase64(Image),ImageCoord=NULL)
  )
}

MQ_Hist_nc<- function(Text=NULL,Question,Points,Titel,N,NCat,breaks,object,iter){
  x1 <- getprobs(N,NCat,5)
  x2 <- getprobs(N,NCat,5)
  while(sum(abs(x1 - x2)) < 0.0001){
    x2 <- getprobs(N,NCat,5)
  }
  x3 <- getprobs(N,NCat,5)
  while((sum(abs(x1 - x2)) < 0.0001) | (sum(abs(x2 - x3)) < 0.0001)){
    x3 <- getprobs(N,NCat,5)
  }
  x4 <- getprobs(N,NCat,5)
  while((sum(abs(x1 - x4)) < 0.0001) | (sum(abs(x2 - x4)) < 0.0001) | (sum(abs(x3 - x4)) < 0.0001) ){
    x4 <- getprobs(N,NCat,5)
  }

  Text <- paste("An vier Universitäten wurden jeweils ", N, "Studenten nach ihren monatlichen Mietkosten befragt. In der nachfolgenden Tabelle sind die absoluten Häufigkeiten an den jeweiligen Universitäten in ", NCat, "Klassen zusammengefasst")
  #breaks <- c(0, 10, 20, 40, 80, 120, 160, 200) #als Argument mitgeben
  dif.b <- diff(breaks)
  obs <- breaks[-length(breaks)] + 0.5*dif.b
  Obs1 <- rep(obs,x1)
  Obs2 <- rep(obs,x2)
  Obs3 <- rep(obs,x3)
  Obs4 <- rep(obs,x4)

  x <- cbind(x1,x2,x3,x4)
  colnames(x) <- c("Universität 1","Universität 2","Universität 3","Universität 4")
  rownames(x) <- sapply(1:NCat, function(j) paste(breaks[j],"b.u.",breaks[j+1]))

  X <- cbind(Obs1,Obs2,Obs3,Obs4)
  sample.col <- sample(1:4,4,replace=F)

  hist4MQ <- function(y,num){
    hist(y,breaks=breaks,col="yellow",main=paste("Histogramm",num),xlab="Klassierte Ausgaben für Mietkosten", ylab="Höhe",border="blue")
  }

  Image <- tempfile(pattern = "file", tmpdir = tempdir())
  jpeg(filename= Image, quality = 100, width = 672, height = 671)

  par(mfrow=c(2,2))
  hist4MQ(X[,sample.col[1]],1)
  hist4MQ(X[,sample.col[2]],2)
  hist4MQ(X[,sample.col[3]],3)
  hist4MQ(X[,sample.col[4]],4)

  dev.off()			# Beendet die Speicherung als .jpeg

  fix.group <- sapply(1:4, function(i) paste("Histogramm ",i,sep=""))
  matching.group <- sapply(1:4, function(i) paste("Verteilung der absoluten Häufigkeiten an der Universität ",i,sep=""))

  Answer <- cbind(fix.group,sapply(1:4, function(i) matching.group[sample.col[i]]))
  dimnames(Answer) <- NULL

  tab         <- matrix(NA, nrow=NCat+1, ncol=5)
  tab[1,1]    <- object
  tab[-1,1]   <- sapply(1:NCat, function(j) rownames(x)[j])
  tab[1,-1]   <- sapply(1:4, function(j) colnames(x)[j])
  tab[-1,-1]  <- x

  return(
      Question(Type="Matching", Text=Text, Tab=tab, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=rep(Points,4), Image=GetBase64(Image),ImageCoord=NULL)
  )
}

# MQ für Boxplots

MQ_Box<- function(Text,Question,Points,Titel,n,range1,range2,range3,range4,iter,Info,IMG){
  x1 <- sample(range1,n,replace=T)
  x2 <- sample(range2,n,replace=T)
  x3 <- sample(range3,n,replace=T)
  x4 <- sample(range4,n,replace=T)

  x <- rbind(x1,x2,x3,x4)

  sample.row <- sample(1:4,4,replace=F)

  box4MQ <- function(y,num){
    boxplot(y,main=paste("Boxplot",num))
  }

  Image <- tempfile(pattern = "file", tmpdir = tempdir())
  jpeg(filename= Image, quality = 100, width = 672, height = 671)

  if(IMG=="sep"){

    par(mfrow=c(2,2))
    box4MQ(x[sample.row[1],],1)
    box4MQ(x[sample.row[2],],2)
    box4MQ(x[sample.row[3],],3)
    box4MQ(x[sample.row[4],],4)

  }

  else {
    boxplot(x[sample.row[1],],x[sample.row[2],],x[sample.row[3],],x[sample.row[4],], names = sapply(1:4, function(j) paste("Boxplot", j)))
  }

  dev.off()			# Beendet die Speicherung als .jpeg
  fix.group <- sapply(1:4, function(i) paste("Boxplot",i,sep=""))
  matching.group <- sapply(1:4, function(i) paste(Info,i,sep=""))

  Answer <- cbind(fix.group,sapply(1:4, function(i) matching.group[sample.row[i]]))
  colnames(Answer) <- NULL

  tab         <- matrix(NA, nrow=5, ncol=n+1)
  tab[1,1]    <- "Beobachtungen"
  tab[-1,1]   <- sapply(1:4, function(i) paste(Info,i))
  tab[1,-1]   <- 1:n
  tab[-1,-1]  <- x

  return(
      Question(Type="Matching", Text=Text, Tab=tab, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=rep(Points,4), Image=GetBase64(Image),ImageCoord=NULL)
  )
}

## QuestionPool <- sapply(1:200, function(i) MQ_Box(
##                     Text = "Sie erhalten die folgenden vier Verteilungen über die erreichte Punktzahl in einem Physiktest.",
##                     Question = "Ordnen sie die vier Verteilungen den jeweiligen Boxplots zu.",
##                     Points = 0.1,
##                     Titel = "DS.K3.MQ.001.",
##                     n = 20,
##                     range1 = 15:25,
##                     range2 = 22:33,
##                     range3 = 12:28,
##                     range4 = 18:30,
##                     iter = i,
##                     IMG  = "sep"
##             ))

MQ_Hist <- function(Text,Question,Points,Titel,mu,sigma,N,iter){
  X <- matrix(NA,ncol=4,nrow=N)
  X <- sapply(1:4, function(i) X[,i] <- rnorm(N,mu[i],sigma[i]))
  mu.emp <- round(apply(X,2,mean),2)
  sig.emp <- round(apply(X,2,sd),2)

  sample.col <- sample(1:4,4,replace=F)

  hist4MQ <- function(y,num){
    hist(y,breaks=10,col="blue",main=paste("Histogramm",num),xlab="",ylab="absolute Häufigkeiten")
  }

  Image <- tempfile(pattern = "file", tmpdir = tempdir())
  jpeg(filename= Image, quality = 100, width = 672, height = 671)

  par(mfrow=c(2,2))
  hist4MQ(X[,sample.col[1]],1)
  hist4MQ(X[,sample.col[2]],2)
  hist4MQ(X[,sample.col[3]],3)
  hist4MQ(X[,sample.col[4]],4)

  dev.off()			# Beendet die Speicherung als .jpeg

  tab <- matrix(NA,nrow=3,ncol=5)
  tab[1,1]   <- "Parameter"
  tab[-1,1]  <- c("Mittelwert","Standardabweichung")
  tab[1,-1]  <- sapply(1:4, function(i) paste("Stichprobe",i))
  tab[-1,-1]  <- rbind(mu.emp,sig.emp)

  fix.group <- sapply(1:4, function(i) paste("Histogramm ",i,sep=""))
  matching.group <- sapply(1:4, function(i) paste("Stichprobe ",i,sep=""))

  Answer <- cbind(fix.group,sapply(1:4, function(i) matching.group[sample.col[i]]))
  dimnames(Answer) <- NULL

  return(
      Question(Type="Matching", Text=Text, Tab=tab, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=rep(Points,4), Image=GetBase64(Image),ImageCoord=NULL)
  )

}

## QuestionPool <- sapply(1:200, function(i) MQ_Hist(
##                     Text     = "Gegeben sind der Mittelwert [tex]\\bar{x}[/tex] und die Standardabweichung [tex]s^2[/tex] von vier Stichproben.",
##                     Question = "Ordnen sie die vier Kenngrößen den passenden Histogrammen zu.",
##                     Points   = 0.1,
##                     Titel    = "DS.K3.MQ.002.",
##                     mu       = c(2,3.5,7,3),
##                     sigma    = c(2,0.5,1.5,1),
##                     N        = 1000,
##                     iter     = i
##             ))

##
VierTabs3x3 <- function(tab1,tab2,tab3,tab4){

  par(mar=c(0,0,0,0))
  plot(1,1,xlim=c(0,2),ylim=c(0,2),col="white",xlab="",ylab="",axes = FALSE)
# Feld 1
  ax=0
  ay=1.05
  text("Tabelle 1",x=ax+0.025,y=ay+0.6,pos=2, srt = 90)
  lines(ax+c(0.05,0.05,0.95,0.95,0.05),ay+c(0.05,0.95,0.95,0.05,0.05))
  lines(ax+c(0.35,0.35),ay+c(0.05,0.95))
  lines(ax+c(0.65,0.65),ay+c(0.05,0.95))
  lines(ax+c(0.05,0.95),ay+c(0.65,0.65))
  lines(ax+c(0.05,0.95),ay+c(0.35,0.35))
  text(tab1[1,1],x=ax+0.2,y=ay+0.8)
  text(tab1[1,2],x=ax+0.5,y=ay+0.8)
  text(tab1[1,3],x=ax+0.8,y=ay+0.8)
  text(tab1[2,1],x=ax+0.2,y=ay+0.5)
  text(tab1[2,2],x=ax+0.5,y=ay+0.5)
  text(tab1[2,3],x=ax+0.8,y=ay+0.5)
  text(tab1[3,1],x=ax+0.2,y=ay+0.2)
  text(tab1[3,2],x=ax+0.5,y=ay+0.2)
  text(tab1[3,3],x=ax+0.8,y=ay+0.2)

# Feld 2
  ax=1.05
  ay=1.05
  text("Tabelle 2",x=ax+0.025,y=ay+0.6,pos=2, srt = 90)
  lines(ax+c(0.05,0.05,0.95,0.95,0.05),ay+c(0.05,0.95,0.95,0.05,0.05))
  lines(ax+c(0.35,0.35),ay+c(0.05,0.95))
  lines(ax+c(0.65,0.65),ay+c(0.05,0.95))
  lines(ax+c(0.05,0.95),ay+c(0.65,0.65))
  lines(ax+c(0.05,0.95),ay+c(0.35,0.35))
  text(tab2[1,1],x=ax+0.2,y=ay+0.8)
  text(tab2[1,2],x=ax+0.5,y=ay+0.8)
  text(tab2[1,3],x=ax+0.8,y=ay+0.8)
  text(tab2[2,1],x=ax+0.2,y=ay+0.5)
  text(tab2[2,2],x=ax+0.5,y=ay+0.5)
  text(tab2[2,3],x=ax+0.8,y=ay+0.5)
  text(tab2[3,1],x=ax+0.2,y=ay+0.2)
  text(tab2[3,2],x=ax+0.5,y=ay+0.2)
  text(tab2[3,3],x=ax+0.8,y=ay+0.2)
# Feld 3
  ax=0
  ay=0
  text("Tabelle 3",x=ax+0.025,y=ay+0.6,pos=2, srt = 90)
  lines(ax+c(0.05,0.05,0.95,0.95,0.05),ay+c(0.05,0.95,0.95,0.05,0.05))
  lines(ax+c(0.35,0.35),ay+c(0.05,0.95))
  lines(ax+c(0.65,0.65),ay+c(0.05,0.95))
  lines(ax+c(0.05,0.95),ay+c(0.65,0.65))
  lines(ax+c(0.05,0.95),ay+c(0.35,0.35))
  text(tab3[1,1],x=ax+0.2,y=ay+0.8)
  text(tab3[1,2],x=ax+0.5,y=ay+0.8)
  text(tab3[1,3],x=ax+0.8,y=ay+0.8)
  text(tab3[2,1],x=ax+0.2,y=ay+0.5)
  text(tab3[2,2],x=ax+0.5,y=ay+0.5)
  text(tab3[2,3],x=ax+0.8,y=ay+0.5)
  text(tab3[3,1],x=ax+0.2,y=ay+0.2)
  text(tab3[3,2],x=ax+0.5,y=ay+0.2)
  text(tab3[3,3],x=ax+0.8,y=ay+0.2)


# Feld 4
  ax=1.05
  ay=0
  text("Tabelle 4",x=ax+0.025,y=ay+0.6,pos=2, srt = 90)
  lines(ax+c(0.05,0.05,0.95,0.95,0.05),ay+c(0.05,0.95,0.95,0.05,0.05))
  lines(ax+c(0.35,0.35),ay+c(0.05,0.95))
  lines(ax+c(0.65,0.65),ay+c(0.05,0.95))
  lines(ax+c(0.05,0.95),ay+c(0.65,0.65))
  lines(ax+c(0.05,0.95),ay+c(0.35,0.35))
  text(tab4[1,1],x=ax+0.2,y=ay+0.8)
  text(tab4[1,2],x=ax+0.5,y=ay+0.8)
  text(tab4[1,3],x=ax+0.8,y=ay+0.8)
  text(tab4[2,1],x=ax+0.2,y=ay+0.5)
  text(tab4[2,2],x=ax+0.5,y=ay+0.5)
  text(tab4[2,3],x=ax+0.8,y=ay+0.5)
  text(tab4[3,1],x=ax+0.2,y=ay+0.2)
  text(tab4[3,2],x=ax+0.5,y=ay+0.2)
  text(tab4[3,3],x=ax+0.8,y=ay+0.2)
}

ContCoef <- function(X){
  dims <- dim(X)
  n <- sum(X)
  XC <- cbind(X,rowSums(X))
  XCR <- rbind(XC,colSums(XC))

  Xnull <- t(sapply(1:dims[1], function(i) sapply(1:dims[2], function(j) XCR[i,dims[2]+1]*XCR[dims[1]+1,j]/n)))
  Chi2 <- sum((X-Xnull)^2/Xnull)
  K <- sqrt(Chi2/(n+Chi2))
  Kmax <- sqrt((min(dims)-1)/min(dims))
  Kstar <- K/Kmax

  return(Kstar)
}

MQ_Cont <- function(Text, Question=NULL, iter, Titel, Points, Xlist){
  s <- sample(1:length(Xlist),4)
  X1 <- Xlist[[s[1]]]
  X2 <- Xlist[[s[2]]]
  X3 <- Xlist[[s[3]]]
  X4 <- Xlist[[s[4]]]

  T1 <- T2 <- T3 <- T4 <- matrix(NA,ncol=3,nrow=3)
  T1[1,] <- T2[1,] <- T3[1,] <- T4[1,] <- c("","Y1","Y2")
  T1[-1,1] <- T2[-1,1] <- T3[-1,1] <- T4[-1,1] <- c("X1", "X2")
  T1[-1,-1] <- X1
  T2[-1,-1] <- X2
  T3[-1,-1] <- X3
  T4[-1,-1] <- X4


  K1 <- ContCoef(X1)
  K2 <- ContCoef(X2)
  K3 <- ContCoef(X3)
  K4 <- ContCoef(X4)

  sampO <- sample(1:4,4)
  K <- round(c(K1,K2,K3,K4),4)[sampO]

  Image <- tempfile(pattern = "file", tmpdir = tempdir())
  jpeg(filename= Image, quality = 100, width = 672, height = 671)
  VierTabs3x3(T1,T2,T3,T4)
  dev.off()

  fix.group <- sapply(1:4, function(i) paste("Tabelle", i, sep = ""))
  matching.group <- sapply(1:4, function(i) paste("Der normierte Kontingenzkoeffizient beträgt ", K[sampO==i], sep = ""))
  Answer <- cbind(fix.group, sapply(1:4, function(i) matching.group[[i]]))
  colnames(Answer) <- NULL

  return(Question(Type = "Matching", Text = Text, Titel = paste(Titel, sprintf("%05d", iter), sep = ""),  Question = Question, Answer = Answer,
          Points = rep(Points, 4), Image = GetBase64(Image), ImageCoord = NULL))

}

#######################################################################################################################################################
#
# 		ORDERING QUESTIONS
#
#######################################################################################################################################################


### 1) Ordering question: Simple elements



OQ_SimpleElements <- function(Text,Question,Points,Titel,iter,RankingElements){

  Answer <- sort(RankingElements)

  return(
    Question(Type="Ordering", Text=Text, Tab=NULL, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=Points)
  )
}

### Example for function call:

#OQ_SimpleElements(

#    Text = NULL,   # Description of task or issue of the question; NULL if no text is needed
#    Titel = "Question_OQ_SimpleElements_",     # Number or content of the question
#    Quest = "Please rank the given capital letters in the correct way, beginning with the letter that occurs first in the alphabet.",   # Formulation of a concrete question (Questions and/or Text can contain LaTeX elements).
#    Points = 2,     # The achievable number of points -> only if all elements are ranked in the only correct way, points can be achieved
#    iter = x,      # Number of different questions that should be generated
#    RankingElements = sample(LETTERS,4)  # Group of elements/categories, which should be ranked in the process of question

#)


# Further comments:
# -
# -



### 2) Ordering question: Random elements with switching question

OQ_RankRandomElements <- function (Text=NULL, Questions, Points, Titel, iter, RankingGroups, ways="asc")
{
  if (length(Questions) > 2) stop("OQ_RankRandomElements works with max 2 Questions")
  Qsam <- sample(1:length(Questions), 1)
  sampled.elements <- sapply(RankingGroups,function(x)sample(x,1))
  if (length(Questions)==2){
      ways <- c("asc","desc")[Qsam]
    }
  if(ways == "asc") {
    Answer <- sampled.elements
  } else{
    Answer <- sampled.elements[length(sampled.elements):1]
  }
  return(Question(Type = "Ordering", Text = Text, Tab = NULL,
          Titel = paste(Titel, sprintf("%05d", iter), sep = ""),
          Question = Questions[Qsam], Answer = Answer, Points = Points))
}

### Example for function call:

#OQ_RankRandomElements(

#    Text = NULL,   # Description of task or issue of the question; NULL if no text is needed
#    Titel = "Question_OQ_RankRandomElements_",     # Number or content of the question
#    Quest = Question,   # Formulation of a concrete question (Questions and/or Text can contain LaTeX elements). Question is defined within the function.
#    Points = 2,     # The achievable number of points -> only if all elements are ranked in the only correct way, points can be achieved
#    iter = x,      # Number of different questions that should be generated
#    RankingGroup1 = c("Gender","Colors","Party affiliation")   ,   # Group 1 of elements, which should ranked with regard to to other elements -> one is randomly drawn within the function
#    RankingGroup2 = c("School grades","Clothing sizes","Boxing weight classes","Service grade in the army")  ,    # Group 2 of elements
#    RankingGroup3 = c("Temperature in C","Temperature in F","Year dates","Calendar data")  ,    # Group 3 of elements
#    RankingGroup4 = c("GDP","Net income","Height","Weight","Speed","Temperature in K","Household size")      # Group 4 of elements
#)


# Further comments:
# -
# -








#######################################################################################################################################################
#
# 		IMAGE MAP QUESTIONS
#
#######################################################################################################################################################



# 1) Image map question: Include a simple regression analysis in R


IMQ_Reg <- function(Text,Question,Points,Titel,iter,x,y){

    mod<-(lm(y~x))

    Image <- tempfile(pattern = "file", tmpdir = tempdir())			# path for temporary image file
    jpeg(filename=Image, quality = 100, width=672, height=671)				# parameters of temporary image file

### Extract elements of R-outputs and write them into .jpeg-file

    plot(1:1000,1:1000,col=FALSE, axes=FALSE, xlab=NA, ylab=NA, main="Linear simple regression model")
    Reg.model <- "Regression model:"
    text(20,1000, paste(Reg.model), pos=4)

    # Modell

    Call <- "Call:"
    text(20,900, paste(Call), pos=4)
    formula <- "lm(formula = y ~ x)"
    text(20,850, paste(formula), pos=4)

    # residuals

    Residuals <- "Residuals:"
    text(20,750, paste(Residuals), pos=4)
    min.res <- "Min"
    text(20,700, paste(min.res), pos=4)
    Q1.res <- "1Q"
    text(150,700, paste(Q1.res), pos=4)
    Med.res <- "Median"
    text(280,700, paste(Med.res), pos=4)
    Q3.res <- "3Q"
    text(450,700, paste(Q3.res), pos=4)
    max.res <- "Max"
    text(580,700, paste(max.res), pos=4)

    text(20,650, paste(round(min(mod$res),4)), pos=4)
    text(150,650, paste(round(quantile(mod$res, probs=0.25),4)), pos=4)
    text(280,650, paste(round(quantile(mod$res, probs=0.5),4)), pos=4)
    text(450,650, paste(round(quantile(mod$res, probs=0.75),4)), pos=4)
    text(580,650, paste(round(max(mod$res),4)), pos=4)

    # coefficients

    Coeff <- "Coefficients:"
    text(20,550, paste(Coeff), pos=4)

    Est <- "Estimate"
    text(200,500, paste(Est), pos=4)
    SE <- "Std.Error"
    text(400,500, paste(SE), pos=4)
    tvalue <- "t value"
    text(600,500, paste(tvalue), pos=4)
    pvalue <- "Pr(>|t|)"
    text(800,500, paste(pvalue), pos=4)

    Intercept <- "(Intercept)"
    text(20,450, paste(Intercept), pos=4)
    text(200,450, paste(round(summary(mod)$coeff[1,1],4)), pos=4)
    text(400,450, paste(round(summary(mod)$coeff[1,2],4)), pos=4)
    text(600,450, paste(round(summary(mod)$coeff[1,3],4)), pos=4)

    if(summary(mod)$coeff[1,4] < 0.001) text(800,450, paste(sprintf("%G",summary(mod)$coeff[1,4])), pos=4)
    if(summary(mod)$coeff[1,4] > 0.001) text(800,450,paste(round(summary(mod)$coeff[1,4],5)), pos=4)
    if(summary(mod)$coeff[1,4] < 0.001) text(930,450,paste("***"), pos=4)
    if(0.001 <= summary(mod)$coeff[1,4] & summary(mod)$coeff[1,4] < 0.01) text(930,450,paste("**"), pos=4)
    if(0.01 <= summary(mod)$coeff[1,4] & summary(mod)$coeff[1,4] < 0.05) text(930,450,paste("*"), pos=4)
    if(0.05 <= summary(mod)$coeff[1,4] & summary(mod)$coeff[1,4] < 0.1) text(930,450,paste("."), pos=4)

    x <- "x"
    text(20,400, paste(x), pos=4)
    text(200,400, paste(round(summary(mod)$coeff[2,1],4)), pos=4)
    text(400,400, paste(round(summary(mod)$coeff[2,2],4)), pos=4)
    text(600,400, paste(round(summary(mod)$coeff[2,3],4)), pos=4)

    if(summary(mod)$coeff[2,4] < 0.001) text(800,400, paste(sprintf("%G",summary(mod)$coeff[1,4])), pos=4)
    if(summary(mod)$coeff[2,4] > 0.001) text(800,400,paste(round(summary(mod)$coeff[2,4],5)), pos=4)
    if(summary(mod)$coeff[2,4] < 0.001) text(930,400,paste("***"), pos=4)
    if(0.001 <= summary(mod)$coeff[2,4] & summary(mod)$coeff[2,4] < 0.01) text(930,400,paste("**"), pos=4)
    if(0.01 <= summary(mod)$coeff[2,4] & summary(mod)$coeff[2,4] < 0.05) text(930,400,paste("*"), pos=4)
    if(0.05 <= summary(mod)$coeff[2,4] & summary(mod)$coeff[2,4] < 0.1) text(930,400,paste("."), pos=4)

    # Significance codes:

    striche <- "---"
    text(20,350, paste(striche), pos=4)
    sig.codes <- "Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1"
    text(20,300, paste(sig.codes), pos=4)

    # Residuen.std.err, R.Squared, DF, F-statistic

    res.std.err <- "Residual standard error:"
    on <- "on"
    df.text <- "degrees of freedom"
    text(20,200,paste(c(res.std.err,round(summary(mod)$sigma,4),on,summary(mod)$df[2],df.text), collapse="   "), pos=4)

    M.R.Squared <- "Multiple R-squared:"
    adj.R.Squared <- "Adjusted R-Squared:"
    text(20,150,paste(c(M.R.Squared, round(summary(mod)$r.squared,6)), collapse="   "), pos=4)
    text(450,150,paste(c(adj.R.Squared, round(summary(mod)$adj.r.squared,6)), collapse="   "), pos=4)

    F.stat <- "F-statistic:"
    and <- "and"
    df <- "DF,"
    p.value <- "p-value:"
    text(20,100,paste(c(F.stat,round(summary(mod)$fstatistic[1],5),on,round(summary(mod)$fstatistic[2]),and,round(summary(mod)$fstatistic[3]),df,p.value,round(summary(mod)$coeff[2,4],4)), collapse="   "), pos=4)

    dev.off()    # close temporary image file

    GetBase64 <-function(Output){
        require(RCurl)
        img = readBin(Output, "raw", file.info(Output)[1, "size"])
        b64 = base64Encode(img, "character")
        b64[1]
    }

    Potential.QuestReg <- c("Question 1","Question 2","Question 3","Question 4","Question 5","Question 6","Question 7","Question 8","Question 9","Question 10","Question 11")
    Question <- sample(Potential.QuestReg,1)

    PointsChangingQuests <- function(PotentialQuests,Question,points){
    (PotentialQuests %in% Question ) * points
    }

    Answer <- c(rep("Link",length(Potential.QuestReg)))

  return(
    Question(Type="ImageMap", Text=Text, Tab=NULL, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=PointsChangingQuests(Potential.QuestReg, Question, Points),Base64Image=GetBase64(Image),ImageCoord=list(c(180,340,255,363),c(180,367,255,390),c(285,340,370,363),c(285,367,370,390),c(395,340,470,363),c(395,367,470,390),c(500,340,620,363),c(500,367,620,390),c(230,465,292,488),c(300,465,350,488),c(200,492,280,515)))
  )
}

### Example for function call:

#IMQ_Reg(

#    Text = "A regression analysis of two variables has the following results:",   # Description of task or issue of the question; NULL if no text is needed
#    Titel = "Question_IM_Reg_",     # Number or content of the question
#    Quest = Question,   # Formulation of a concrete question (Questions and/or Text can contain LaTeX elements). Question is defined within the function.
#    Points = 3 ,     # The achievable number of points is depending on the number of possible matchings -> for each matching there must be allocated the same number of points
#    iter = x,      # Number of different questions that should be generated
#    x = sample(1:25,10),     # vector of values for x variable
#    y = sample(20:80,10)     # vector of values for y variable
#)

# Further comments:
# -
# -






# 2) Image map question: Include an one sample t-test in R



IMQ_1sample.test <- function(Text,Question,Base64Image,ImageCoord,Points,Titel,iter,x,hypothesis,test.value,confidence.level){

    test <- t.test(x, alternative=hypothesis, mu=test.value, conf.level=confidence.level)

    Image <-tempfile(pattern = "file", tmpdir = tempdir())	# path for temporary image file
    jpeg(filename=Image, quality = 100, width=700, height=700)				# parameters of temporary image file

### Extract elements of R-outputs and write them into .jpeg-file

    plot(1:1000,1:1000,col=FALSE,axes=FALSE, xlab=NA, ylab=NA, main="One Sample t-test")
    S1.test <- "One Sample t-test"
    text(200,950, paste(S1.test), pos=4)

    data <- "data:"
    text(20,850,paste(c(data,test$data.name), collapse="   "), pos=4)

    t <- "t  ="
    df <- "df  ="
    pvalue <- "p-value  ="
    text(20,780, paste(c(t,round(test$statistic,4)), collapse="  "), pos=4)
    text(250,780,paste(c(df,test$parameter), collapse="  "), pos=4)
    if(test$p.value < 0.001) text(450,780, paste(c(pvalue,sprintf("%G",test$p.value)), collapse="   "), pos=4)
    if(test$p.value > 0.001) text(450,780,paste(c(pvalue,round(test$p.value,5)), collapse="   "), pos=4)


    alternative <- "alternative hypothesis:"
    text(20,710, paste(alternative), pos=4)
    if(hypothesis=="two.sided") text(270,710, paste(c("true mean is not equal to",test$null.value), collapse="   "), pos=4)
    if(hypothesis=="less") text(270,710, paste(c("true mean is less than",test$null.value), collapse="   "), pos=4)
    if(hypothesis=="greater") text(270,710, paste(c("true mean is greater than",test$null.value), collapse="   "), pos=4)

    if(confidence.level==0.9) text(20,640, paste(90), pos=4)
    if(confidence.level==0.95) text(20,640, paste(95), pos=4)
    if(confidence.level==0.99) text(20,640, paste(99), pos=4)
    conf.int <- "percent confidence interval:"
    text(80,640, paste(conf.int), pos=4)

    text(20,570,paste(c(round(test$conf.int[1],8), round(test$conf.int[2],8)), collapse="     "), pos=4)

    est <- "sample estimates:"
    text(20,500,paste(est), pos=4)

    mean <- "mean of x"
    text(20,430,paste(mean), pos=4)

    text(20,360,paste(round(test$estimate,8)), pos=4)


    dev.off()    # close temporary image file

    GetBase64 <-function(Output){
        require(RCurl)
        img = readBin(Output, "raw", file.info(Output)[1, "size"])
        b64 = base64Encode(img, "character")
        b64[1]
    }

    Potential.QuestReg <- c("Question 1","Question 2","Question 3","Question 4","Question 5","Question 6","Question 7")
    Question <- sample(Potential.QuestReg,1)

    PointsChangingQuests <- function(PotentialQuests,Question,points){
    (PotentialQuests %in% Question ) * points
    }

    Answer <- c(rep("Link",length(Potential.QuestReg)))

  return(
    Question(Type="ImageMap", Text=Text, Tab=NULL, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=PointsChangingQuests(Potential.QuestReg, Question, Points),Base64Image=GetBase64(Image),ImageCoord=list(c(85,175,195,210),c(215,175,310,210),c(330,175,510,210),c(220,215,470,250),c(85,255,130,283),c(85,288,310,325),c(85,395,210,435)))
  )
}

### Example for function call:

#IMQ_1sample.test(

#    Text = "A one sample t-test of a metric variable has the following results:",   # Description of task or issue of the question; NULL if no text is needed
#    Titel = "Question_IM_1sample.test_",     # Number or content of the question
#    Quest = Question,   # Formulation of a concrete question (Questions and/or Text can contain LaTeX elements). Question is defined within the function.
#    Points = 3,     # The achievable number of points is depending on the number of possible matchings -> for each matching there must be allocated the same number of points
#    iter = x,      # Number of different questions that should be generated
#    x = sample(-2:5,20,TRUE),     # vector of values for x variable
#    hypothesis = sample(c("two.sided","greater","less"),1),     # type of hypothesis
#    test.value = 0,     # Which value should be tested
#    confidence.level = sample(c(0.9,0.95,0.99),1)   # choose a confidence level for the test
#)

# Further comments:
# -
# -





# 3) Image map question: Include a two sample t-test in R


IMQ_2sample.test <- function(Text,Question,Base64Image,ImageCoord,Points,Titel,iter,x,y,hypothesis,test.value,confidence.level){

    test <- t.test(x,y, alternative=hypothesis, mu=test.value, conf.level=confidence.level)

    Image <- tempfile(pattern = "file", tmpdir = tempdir())			# path for temporary image file
    jpeg(filename=Image, quality = 100, width=700, height=700)				# parameters of temporary image file

### Extract elements of R-outputs and write them into .jpeg-file

    plot(1:1000,1:1000,col=FALSE, axes=FALSE, xlab=NA, ylab=NA, main="Two Sample t-test")
    S2.test <- "Two Sample t-test"
    text(200,950, paste(S2.test), pos=4)

    data <- "data:"
    text(20,850,paste(c(data,test$data.name), collapse="   "), pos=4)

    t <- "t  ="
    df <- "df  ="
    pvalue <- "p-value  ="
    text(20,780, paste(c(t,round(test$statistic,4)), collapse="  "), pos=4)
    text(250,780,paste(c(df,round(test$parameter,4)), collapse="  "), pos=4)
    if(test$p.value < 0.001) text(450,780, paste(c(pvalue,sprintf("%G",test$p.value)), collapse="   "), pos=4)
    if(test$p.value > 0.001) text(450,780,paste(c(pvalue,round(test$p.value,5)), collapse="   "), pos=4)

    alternative <- "alternative hypothesis:"
    text(20,710, paste(alternative), pos=4)
    if(hypothesis=="two.sided") text(270,710, paste(c("true difference in means is not equal to",test$null.value), collapse="   "), pos=4)
    if(hypothesis=="less") text(270,710, paste(c("true difference in means is less than",test$null.value), collapse="   "), pos=4)
    if(hypothesis=="greater") text(270,710, paste(c("true difference in means is greater than",test$null.value), collapse="   "), pos=4)

    if(confidence.level==0.9) text(20,640, paste(90), pos=4)
    if(confidence.level==0.95) text(20,640, paste(95), pos=4)
    if(confidence.level==0.99) text(20,640, paste(99), pos=4)
    conf.int <- "percent confidence interval:"
    text(80,640, paste(conf.int), pos=4)

    text(20,570,paste(c(round(test$conf.int[1],8), round(test$conf.int[2],8)), collapse="     "), pos=4)

    est <- "sample estimates:"
    text(20,500,paste(est), pos=4)

    mean.x <- "mean of x"
    mean.y <- "mean of y"
    text(20,430,paste(mean.x), pos=4)
    text(250,430,paste(mean.y), pos=4)

    text(20,360,paste(round(test$estimate[1],8)), pos=4)
    text(250,360,paste(round(test$estimate[2],8)), pos=4)


    dev.off()    # close temporary image file

    GetBase64 <-function(Output){
        require(RCurl)
        img = readBin(Output, "raw", file.info(Output)[1, "size"])
        b64 = base64Encode(img, "character")
        b64[1]
    }

    Potential.QuestReg <- c("Question 1","Question 2","Question 3","Question 4","Question 5","Question 6","Question 7","Question 8")
    Question <- sample(Potential.QuestReg,1)

    PointsChangingQuests <- function(PotentialQuests,Question,points){
    (PotentialQuests %in% Question ) * points
    }

    Answer <- c(rep("Link",length(Potential.QuestReg)))

  return(
    Question(Type="ImageMap", Text=Text, Tab=NULL, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=PointsChangingQuests(Potential.QuestReg, Question, Points),Base64Image=GetBase64(Image),ImageCoord=list(c(85,175,195,210),c(215,175,310,210),c(330,175,510,210),c(220,215,510,250),c(85,255,130,283),c(85,288,310,325),c(85,395,195,435),c(215,395,325,435)))
  )
}

#### Example for function call:

#IMQ_2sample.test(

#    Text = "A two sample t-test of two normally distributed random variables has the following results:",   # Description of task or issue of the question; NULL if no text is needed
#    Titel = "Question_IM_2sample.test_",     # Number or content of the question
#    Quest = Question,   # Formulation of a concrete question (Questions and/or Text can contain LaTeX elements). Question is defined within the function.
#    Points = 3,     # The achievable number of points is depending on the number of possible matchings -> for each matching there must be allocated the same number of points
#    iter = x,      # Number of different questions that should be generated
#    x = rnorm(10,4,4),     # vector normally distributed values
#    y = rnorm(10,5,3),     # vector normally distributed values
#    hypothesis = sample(c("two.sided","greater","less"),1),     # type of hypothesis
#    test.value = 0,     # Which value should be tested
#    confidence.level = sample(c(0.9,0.95,0.99),1)   # choose a confidence level for the test
#)

## Further comments:
## -
# -


