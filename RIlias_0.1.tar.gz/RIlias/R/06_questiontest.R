#' @title TestGaps
#' @examples
#' \dontrun{
#' QP <- lapply(1,function(i)TestGaps("ganz viel text","ein toller Titel",i))
#' MakeIliasFiles(QP,Path="/tmp",FolderName="testgap",PoolName="testgap",id="lala",Author="Lehrstuhl Wirtschafts- und Sozialstatistik Trier",debug=FALSE)
#' } 
TestGaps<- function(Text,Titel,iter){
  Question <- list(c("textfrageTeil1","textfrageTeil2?"),c("dropfrageTeil1","dropfrageTeil2."),c("numerische Lueckefrage Teil1","numerische Lueckefrage Teil2:") )
  Answer <- list()
  # Frage mit text
  Answer[[1]] <- list(type="text",labels=c("rot","gruen","blau"),true=c(TRUE,FALSE,FALSE))
  # Frage mit drop
  Answer[[2]] <- list(type="drop",labels=c("rot","gruen","blau"),true=c(TRUE,FALSE,FALSE)
                      ,shuffle="Yes")
  # Frage mit numerischer Luecke 
  Answer[[3]] <- list(type="num",min=3,max=5,true=4)
  Points <- c(1,2,3)
  return(
    Question(Type="Gaps", Text=Text, Tab=NULL, Titel=paste(Titel,sprintf("%05d",iter),sep=""),Question=Question,Answer=Answer,Points=Points)
  )
}
